<?php

$con=mysqli_connect('localhost','temple','@Ayoola99','ajax');
