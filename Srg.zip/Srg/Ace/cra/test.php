<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>

<div class="par iparys_inherited snipcss-fCbQN">
    <div class="global-header">
        <nav>
            <ul id="wb-tphp" class="wb-init wb-disable-inited">
                <li class="wb-slc"><a class="wb-sl" href="#wb-cont">Skip to main content</a></li>
                <li class="wb-slc"><a class="wb-sl" href="#wb-info">Skip to "About government"</a></li>
                <li class="wb-slc"><a class="wb-sl" href="?wbdisable=true" rel="alternate">Switch to basic HTML version</a></li>
            </ul>
        </nav>
        <header class="">
            <div id="wb-bnr" class="container">
                <div class="row">
                    <section id="wb-lng" class="col-xs-3 col-sm-12 pull-right text-right">
                        <h2 class="wb-inv">Language selection</h2>
                        <div class="row">
                            <div class="col-md-12">
                                <ul class="list-inline mrgn-bttm-0">
                                    <li>
                                        <a lang="fr" href="/fr/agence-revenu/services/services-electroniques/services-numeriques-particuliers/dossier-particuliers.html">
                                            <span class="hidden-xs" translate="no">Français</span>
                                            <abbr title="Français" class="visible-xs h3 mrgn-tp-sm mrgn-bttm-0 text-uppercase" translate="no">fr</abbr>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </section>
                    <div class="brand col-xs-9 col-sm-5 col-md-4" property="publisher" resource="#wb-publisher" typeof="GovernmentOrganization">
                        <a href="/en.html" property="url">
                            <img src="https://www.canada.ca/etc/designs/canada/wet-boew/assets/sig-blk-en.svg" alt="Government of Canada" property="logo">
                            <span class="wb-inv"> / <span lang="fr">Gouvernement du Canada</span>
                            </span>
                        </a>
                        <meta property="name" content="Government of Canada">
                        <meta property="areaServed" typeof="Country" content="Canada">
                        <link property="logo" href="/etc/designs/canada/wet-boew/assets/wmms-blk.svg">
                    </div>
                    <section id="wb-srch" class="col-lg-offset-4 col-md-offset-4 col-sm-offset-2 col-xs-12 col-sm-5 col-md-4">
                        <h2>Search</h2>
                        <form action="/en/revenue-agency/search.html" method="get" name="cse-search-box" role="search">
                            <div class="form-group wb-srch-qry">
                                <label for="wb-srch-q" class="wb-inv">Search Canada.ca</label>
                                <input id="wb-srch-q" list="wb-srch-q-ac" class="wb-srch-q form-control" name="q" type="search" value="" size="34" maxlength="170" placeholder="Search CRA">
                                <datalist id="wb-srch-q-ac">
                                </datalist>
                            </div>
                            <div class="form-group submit">
                                <button type="submit" id="wb-srch-sub" class="btn btn-primary btn-small" name="wb-srch-sub"><span class="glyphicon-search glyphicon"></span><span class="wb-inv">Search</span></button>
                            </div>
                        </form>
                    </section>
                </div>
            </div>
            <hr>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <nav class="gcweb-menu wb-init gcweb-menu-inited" typeof="SiteNavigationElement" id="wb-auto-2">
                            <h2 class="wb-inv">Menu</h2>
                            <button type="button" aria-haspopup="true" aria-expanded="false" aria-label="Press the SPACEBAR to expand or the escape key to collapse this menu. Use the Up and Down arrow keys to choose a submenu item. Press the Enter or Right arrow key to expand it, or the Left arrow or Escape key to collapse it. Use the Up and Down arrow keys to choose an item on that level and the Enter key to access it."><span class="wb-inv">Main </span>Menu <span class="expicon glyphicon glyphicon-chevron-down"></span></button>
                            <ul role="menu" aria-orientation="vertical" data-ajax-replace="/content/dam/canada/sitemenu/sitemenu-v2-en.html" class="wb-init wb-data-ajax-replace-inited" id="wb-auto-3">
                                
                               
                               
                                
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <nav id="wb-bc" property="breadcrumb">
                <h2 class="wb-inv">You are here:</h2>
                <div class="container">
                    <ol class="breadcrumb">
                        <li><a href="/en.html">Canada.ca</a></li>
                        <li><a href="/en/services/taxes.html">Taxes</a></li>
                        <li><a href="/en/revenue-agency/services/e-services.html">Digital services</a></li>
                        <li><a href="/en/revenue-agency/services/e-services/digital-services-individuals.html">Digital services for individuals</a></li>
                    </ol>
                </div>
            </nav>
        </header>
    </div>
</div>
<main property="mainContentOfPage" resource="#wb-main" typeof="WebPageElement" class="container snipcss-CXGZe">
    <div class="mwstitle section">
        <h1 property="name" id="wb-cont" dir="ltr"> My Account for Individuals</h1>
    </div>
    <div class="mwscolumns section">
        <div class="row ">
            <div class="col-md-9">
                <div class="mwsgeneric-base-html parbase section">
                </div>
                <div class="mwsalerts section">
                    <section class="alert alert-info">
                        <h2 class="h3">Introducing a new way to get immediate access to the CRA sign-in services</h2>
                        <p>The CRA has introduced a new identity validation option when registering for the CRA sign-in services. This option allows you to get access in real-time without waiting for a CRA security code in the mail. Learn more about the <a href="/en/revenue-agency/services/e-services/cra-login-services/cra-user-password-help-faqs/registration-process-access-cra-login-services.html#hlpvrfscrtycd">document verification service</a>.&nbsp;</p>
                    </section>
                </div>
                <div class="mwsgeneric-base-html parbase section">
                    <section data-ajax-replace="/content/dam/cra-arc/includes/eservices-outage.txt#ma-rac-outage-en" class="wb-init wb-data-ajax-replace-inited" id="wb-auto-4"></section>
                    <section class="alert alert-warning">
                        <details>
                            <summary>If your CRA user ID and password have been revoked</summary>
                            <p>Some taxpayers may have received a notification that their CRA user ID and password have been revoked. Visit <a href="/en/revenue-agency/corporate/security/revoked-userid.html">CRA user ID and password have been revoked</a> for more information.</p>
                        </details>
                    </section>
                    <section class="alert alert-info">
                        <details>
                            <summary>To make your account more secure, email addresses in My Account are now required</summary>
                            <p>As of February 7, 2022, all My Account users will need to have an email address on file with the CRA to help protect their online accounts from fraudulent activity. If you do not currently have an email address on file, you will be prompted to provide one when you sign in.</p>
                        </details>
                    </section>
                </div>
                <div class="mwsbodytext text parbase section">
                    <p>My Account is a secure portal that lets you view your personal income tax and benefit information and manage your tax affairs online.</p>
                </div>
                <div class="mwsbodytext text parbase section">
                    <p>Choose from one of three ways to access My Account:</p>
                </div>
                <div class="mwsgeneric-base-html parbase section">
                    <section class="provisional alert alert-info">
                        <p><strong>Note:</strong> Before you can register using option 1 or 2, you must have filed your income tax and benefit return for the current tax year or the previous one.</p>
                    </section>
                </div>
                <div class="mwsgeneric-base-html parbase section">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2 class="panel-title">Option 1 – Using one of our Sign-In Partners</h2>
                        </div>
                        <div class="panel-body">
                            <p>Sign in or register with the same sign-in information you use for other online services (for example, online banking).</p>
                            <p class="text-center mrgn-tp-lg"><a data-gc-analytics-customclick="CRA|ARC:Option 1 button click:Sign-In Partner Login/Register button" class="btn btn-call-to-action" role="button" href="https://ams-sga-cra-arc.fjgc-gccf.gc.ca/gol-ged/awsc/amss/commonDomain/w?target=login&amp;lang=en&amp;program=mima&amp;idp=idp1&amp;dm=x">Sign-In Partner</a></p>
                            <p>For the security of your CRA account, when you are on your Sign-In Partner website, <a href="/en/revenue-agency/services/e-services/cra-login-services/sign-partners-help-faqs/security-privacy.html#q1">ensure it is <strong>your</strong> information</a> that is entered and not that of somebody else.</p>
                            <details>
                                <summary tabindex="0" class="text-center" id="wb-auto-1" role="button" aria-expanded="false">View list of Sign-In Partners</summary>
                                <section data-ajax-replace="/content/dam/cra-arc/includes/chooser-page-logos.txt#logos-en" class="wb-init wb-data-ajax-replace-inited" id="wb-auto-5">
                                    <div class="row" id="logos-en">
                                        <div class="col-xs-6 text-center">
                                            <ul class="list-unstyled lst-spcd">
                                                <li>
                                                    <img class="img-responsive center-block" alt="Affinity Credit Union" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/ffnty-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="ATB Financial" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/tb-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="BMO Financial Group" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/bm-dc-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Caisse Alliance" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/caissealliance.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="CIBC" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/cibc.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Coast Capital" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/coastcapital.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Conexus" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/cnxs-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="connectFirst" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/cf.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Desjardins" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/dsjrdns-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Libro" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/libro.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Meridian" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/meridian.gif">
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-xs-6 text-center">
                                            <ul class="list-unstyled lst-spcd">
                                                <li>
                                                    <img class="img-responsive center-block" alt="National Bank" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/nbc-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="RBC Royal Bank" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/rbc-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Scotiabank" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/sc-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Servus Credit Union" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/srvs-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Simplii Financial" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/simp-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Tangerine" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/tngrn-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="TD Canada Trust" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/td-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Uni" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/uni.png">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Vancity" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/vncty-en.gif">
                                                </li>
                                                <li>
                                                    <img class="img-responsive center-block" alt="Wealthsimple" src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/wlthsmpl-en.gif">
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </section>
                            </details>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2 class="panel-title">Option 2 – Using a CRA user ID and password</h2>
                        </div>
                        <div class="panel-body">
                            <p>Sign in with your CRA user ID and password, or register.</p>
                            <div class="col-sm-12">
                                <p class="text-center mrgn-tp-lg"><a data-gc-analytics-customclick="CRA|ARC:Option 2 button click:CRA login button" class="btn btn-call-to-action" role="button" href="https://ams-sga.cra-arc.gc.ca/gol-ged/awsc/amss/entry?target=login&amp;lang=en&amp;program=mima&amp;idp=cms">CRA sign in</a>&nbsp;&nbsp;&nbsp;<a role="button" href="https://ams-sga.cra-arc.gc.ca/gol-ged/awsc/amss/entry?target=register&amp;lang=en&amp;program=mima">CRA register</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2 class="panel-title">Option 3 – Using a provincial partner</h2>
                        </div>
                        <div class="panel-body">
                            <p>Sign in with your Alberta.ca Account or BC Services Card.</p>
                            <div class="col-sm-12">
                                <p class="text-center mrgn-tp-lg"><a class="btn btn-call-to-action" role="button" href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/provincial-partner.html">Provincial partner sign in</a>
                                </p>
                                <details>
                                    <summary class="text-center">View list of provincial partners</summary>
                                    <ul class="list-inline row">
                                        <li class="col-md-4 col-md-offset-2">
                                            <img src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/ablogo.png" alt="My Alberta Digital ID logo" class="img-responsive">
                                        </li>
                                        <li class="col-md-4">
                                            <img src="https://www.canada.ca/content/dam/cra-arc/serv-info/eservices/bc-services-card.png" alt="BC Services Card logo" class="img-responsive">
                                        </li>
                                    </ul>
                                </details>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="mwsgeneric-base-html parbase section">
                    <section class="panel panel-info">
                        <header class="panel-heading">
                            <h2 class="panel-title">Help and FAQs</h2>
                        </header>
                        <div class="panel-body">
                            <ul class="list-group">
                                <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/cra-user-password-help-faqs.html">CRA user ID and password</a></li>
                                <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/sign-partners-help-faqs.html">Sign-In Partners</a></li>
                                <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/provincial-partner-help.html">Provincial partners</a></li>
                                <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/multi-factor-authentication-access-cra-login-services.html">Multi-factor authentication</a></li>
                                <li class="list-group-item"><a href="/en/revenue-agency/services/about-canada-revenue-agency-cra/direct-deposit.html">Direct deposit</a></li>
                            </ul>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
    <div class="mwsbodytext text parbase section">
        <p>&nbsp;</p>
        <p><strong>Representatives</strong> (including friends and family members) can access My Account on behalf of someone else using <a href="/en/revenue-agency/services/e-services/represent-a-client.html">Represent a Client</a>.</p>
        <p>To make an online payment, go to <a href="/en/revenue-agency/services/payments-cra.html">Make a payment</a>. You can also set up a payment plan through My Account.</p>
    </div>
    <div class="mwsgeneric-base-html parbase section">
        <section data-ajax-replace="/content/dam/cra-arc/includes/tlsAlert.txt#tls-en" class="wb-init wb-data-ajax-replace-inited" id="wb-auto-6">
            <section id="tls-en" class="alert alert-danger">
                <p>If you are using an older browser that does not support the <a href="/content/canadasite/en/revenue-agency/corporate/access-online-services-safely.html#h4">latest security standard</a>, you will not be able to access CRA's secure online services. </p>
            </section>
        </section>
    </div>
    <div class="mwsbodytext text parbase section">
        <h2>Topics</h2>
        <ul class="list-group">
            <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/account-whats-new.html"><strong>My Account – What's new</strong></a></li>
            <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/about-account.html"><strong>About My Account</strong></a></li>
            <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/hours-service.html"><strong>Hours of service</strong></a></li>
            <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/represent-a-client.html"><strong>Representatives</strong></a></li>
            <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services.html"><strong>CRA sign-in services</strong></a></li>
            <li class="list-group-item"><a href="/en/revenue-agency/corporate/contact-information.html#h5"><strong>Individual tax enquiries</strong></a></li>
            <li class="list-group-item"><a href="/en/revenue-agency/services/tax/representative-authorization/before.html"><strong>Your responsibilities in managing your authorized representatives</strong></a></li>
        </ul>
    </div>
    <section class="pagedetails">
        <h2 class="wb-inv">Page details</h2>
        <div class="row">
            <div class="col-sm-8 col-md-9 col-lg-9">
                <div class="wb-disable-allow wb-init wb-data-ajax-replace-inited" data-ajax-replace="/etc/designs/canada/wet-boew/assets/feedback/page-feedback-en.html" id="wb-auto-7">
                    <div id="gc-pft" class="row wb-disable-allow wb-init wb-jsonmanager-inited" data-wb-jsonmanager="{
	&quot;name&quot;: &quot;gc-pft&quot;,
	&quot;extractor&quot;: [
		{ &quot;selector&quot;: &quot;title&quot;, &quot;path&quot;: &quot;pageData/pageTitle&quot; },
		{ &quot;selector&quot;: &quot;html&quot;, &quot;attr&quot;: &quot;lang&quot;, &quot;path&quot;: &quot;pageData/language&quot; },
		{ &quot;interface&quot;: &quot;locationHref&quot;, &quot;path&quot;: &quot;pageData/submissionPage&quot; },
		{ &quot;selector&quot;: &quot;#wb-lng ul li:first-child a[lang]&quot;, &quot;attr&quot;: &quot;href&quot;, &quot;path&quot;: &quot;pageData/oppositelang&quot; },
		{ &quot;selector&quot;: &quot;[data-feedback-theme]&quot;, &quot;attr&quot;: &quot;data-feedback-theme&quot;, &quot;path&quot;: &quot;pageData/themeopt&quot; },
		{ &quot;selector&quot;: &quot;[data-feedback-section]&quot;, &quot;attr&quot;: &quot;data-feedback-section&quot;, &quot;path&quot;: &quot;pageData/sectionopt&quot; },
		{ &quot;selector&quot;: &quot;meta[name=\&quot;dcterms.creator\&quot;]&quot;, &quot;attr&quot;: &quot;content&quot;, &quot;path&quot;: &quot;pageData/institutionopt&quot; },
		{ &quot;selector&quot;: &quot;[data-feedback-link]&quot;, &quot;attr&quot;: &quot;data-feedback-link&quot;, &quot;path&quot;: &quot;contact/link&quot; },
		{ &quot;selector&quot;: &quot;[data-feedback-url]&quot;, &quot;attr&quot;: &quot;data-feedback-url&quot;, &quot;path&quot;: &quot;contact/url&quot; }
	]
}">
                        <div class="col-sm-10 col-md-9 col-lg-8">
                            <section class="well mrgn-bttm-0">
                                <h3 class="wb-inv">Give feedback about this page</h3>
                                <form action="https://feedback-retroaction.canada.ca/api/QueueProblemForm" method="post" class="wb-postback wb-disable-allow wb-init wb-postback-inited" data-wb-postback="{&quot;success&quot;:&quot;.gc-pft-thnk&quot;}" id="wb-auto-15">
                                    <div class="wb-disable-allow wb-init wb-data-json-inited" data-wb-json="{
					&quot;url&quot;: &quot;#[gc-pft]/pageData&quot;,
					&quot;mapping&quot;: [
						{ &quot;selector&quot;: &quot;input&quot;, &quot;attr&quot;: &quot;name&quot;, &quot;value&quot;: &quot;/@id&quot; },
						{ &quot;selector&quot;: &quot;input&quot;, &quot;attr&quot;: &quot;value&quot;, &quot;value&quot;: &quot;/@value&quot; }
					]
				}" id="wb-auto-16">
                                        <template class="wb-init wb-template-inited" id="wb-auto-17">
                                            <input type="hidden" name="" value="">
                                        </template>
                                        <input type="hidden" name="pageTitle" value="My Account for Individuals - Canada.ca">
                                        <input type="hidden" name="language" value="en">
                                        <input type="hidden" name="submissionPage" value="https://www.canada.ca/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html">
                                        <input type="hidden" name="oppositelang" value="/fr/agence-revenu/services/services-electroniques/services-numeriques-particuliers/dossier-particuliers.html">
                                        <input type="hidden" name="themeopt" value="">
                                        <input type="hidden" name="sectionopt" value="">
                                        <input type="hidden" name="institutionopt" value="Canada Revenue Agency">
                                    </div>
                                    <fieldset class="gc-pft-btns chkbxrdio-grp row row-no-gutters d-sm-flex flex-sm-wrap align-items-sm-center">
                                        <legend class="col-xs-12 col-sm-7 nojs-col-sm-12 col-md-9 col-lg-8 text-center text-sm-left nojs-text-left mrgn-tp-sm pr-sm-3"><span class="field-name">Did you find what you were looking for?</span></legend>
                                        <div class="col-xs-12 nojs-show">
                                            <button name="helpful" value="Yes-Oui" class="btn btn-primary" aria-describedby="gc-pft-why">Yes</button>
                                        </div>
                                        <div class="col-xs-12 col-sm-5 col-md-3 col-lg-4 text-center text-sm-right nojs-hide">
                                            <button name="helpful" value="Yes-Oui" class="btn btn-primary">Yes</button>
                                            <button class="btn btn-primary mrgn-lft-sm" data-wb-doaction="[
							{&quot;action&quot;:&quot;removeClass&quot;,&quot;source&quot;:&quot;.gc-pft-no&quot;,&quot;class&quot;:&quot;nojs-show&quot;},
							{&quot;action&quot;:&quot;addClass&quot;,&quot;source&quot;:&quot;.gc-pft-btns&quot;,&quot;class&quot;:&quot;hide&quot;}
						]">No</button>
                                        </div>
                                    </fieldset>
                                    <div class="gc-pft-no nojs-show">
                                        <p id="gc-pft-why" class="nojs-show mrgn-tp-lg mrgn-bttm-md">If not, tell us why below:</p>
                                        <p class="nojs-hide wb-inv" aria-live="polite">Tell us why below:</p>
                                        <div class="wb-disable-allow wb-init wb-data-json-inited" data-wb-json="{
						&quot;url&quot;: &quot;#[gc-pft]/contact&quot;,
						&quot;streamline&quot;: &quot;true&quot;,
						&quot;mapping&quot;: [
							{
								&quot;template&quot;: &quot;[data-contact-template]&quot;,
								&quot;test&quot;: &quot;fn:isLiteral&quot;,
								&quot;assess&quot;: &quot;/url&quot;,
								&quot;mapping&quot;: [
									{ &quot;selector&quot;: &quot;a&quot;, &quot;type&quot;: &quot;attr&quot;, &quot;attr&quot;: &quot;href&quot;, &quot;value&quot;: &quot;/url&quot;  },
									{ &quot;selector&quot;: &quot;a&quot;, &quot;value&quot;: &quot;/link&quot;  }
								]
							}
						]
					}" id="wb-auto-18">
                                            <template data-contact-template="" class="wb-init wb-template-inited" id="wb-auto-19">
                                                <details>
                                                    <summary>Need urgent help with a problem? Contact us</summary>
                                                    <p class="mrgn-bttm-0 mrgn-tp-md fnt-nrml">
                                                        <a href="#"></a>
                                                    </p>
                                                </details>
                                            </template>
                                        </div>
                                        <div class="form-group">
                                            <label id="gc-pft-prblm-label" for="gc-pft-prblm" class="mrgn-bttm-0"><span class="field-name">Please provide more details</span></label>
                                            <p id="gc-pft-prblm-note" class="mrgn-bttm-sm"><small>You will not receive a reply. Don't include personal information (telephone, email, SIN, financial, medical, or work details).</small></p>
                                            <p id="gc-pft-prblm-instruction" class="fnt-nrml small">Maximum 300 characters</p>
                                            <textarea id="gc-pft-prblm" aria-describedby="gc-pft-prblm-note gc-pft-prblm-instruction" name="details" class="form-control full-width" maxlength="300"></textarea>
                                        </div>
                                        <button name="helpful" value="No-Non" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                                <div class="gc-pft-thnk hide">
                                    <p class="mrgn-tp-sm mrgn-bttm-0" role="status"><span class="glyphicon glyphicon-ok text-success mrgn-rght-sm" aria-hidden="true"></span> Thank you for your feedback.</p>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wb-share col-sm-4 col-md-3 wb-init wb-share-inited" data-wb-share="{&quot;lnkClass&quot;: &quot;btn btn-default btn-block&quot;}" id="wb-auto-8">
                <section id="shr-pg0" class="shr-pg mfp-hide modal-dialog modal-content overlay-def">
                    <header class="modal-header">
                        <h2 class="modal-title">Share this page</h2>
                    </header>
                    <div class="modal-body">
                        <ul class="list-unstyled colcount-xs-2">
                            <li><a href="https://www.blogger.com/blog_this.pyra?t=&amp;u=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;n=My%20Account%20for%20Individuals%20-%20Canada.ca" class="shr-lnk blogger btn btn-default" rel="noreferrer noopener">Blogger</a></li>
                            <li><a href="https://www.diigo.com/post?url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;title=My%20Account%20for%20Individuals%20-%20Canada.ca" class="shr-lnk diigo btn btn-default" rel="noreferrer noopener">Diigo</a></li>
                            <li><a href="mailto:?subject=My%20Account%20for%20Individuals%20-%20Canada.ca&amp;body=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html%0A" class="shr-lnk email btn btn-default" rel="noreferrer noopener">Email</a></li>
                            <li><a href="https://www.facebook.com/sharer.php?u=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;t=My%20Account%20for%20Individuals%20-%20Canada.ca" class="shr-lnk facebook btn btn-default" rel="noreferrer noopener">Facebook</a></li>
                            <li><a href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;tf=1&amp;to=&amp;su=My%20Account%20for%20Individuals%20-%20Canada.ca&amp;body=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html%0A" class="shr-lnk gmail btn btn-default" rel="noreferrer noopener">Gmail</a></li>
                            <li><a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;title=My%20Account%20for%20Individuals%20-%20Canada.ca&amp;ro=false&amp;summary=&amp;source=" class="shr-lnk linkedin btn btn-default" rel="noreferrer noopener">LinkedIn®</a></li>
                            <li><a href="https://www.myspace.com/Modules/PostTo/Pages/?u=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;t=My%20Account%20for%20Individuals%20-%20Canada.ca" class="shr-lnk myspace btn btn-default" rel="noreferrer noopener">MySpace</a></li>
                            <li><a href="https://www.pinterest.com/pin/create/button/?url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;media=&amp;description=My%20Account%20for%20Individuals%20-%20Canada.ca" class="shr-lnk pinterest btn btn-default" rel="noreferrer noopener">Pinterest</a></li>
                            <li><a href="https://reddit.com/submit?url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;title=My%20Account%20for%20Individuals%20-%20Canada.ca" class="shr-lnk reddit btn btn-default" rel="noreferrer noopener">reddit</a></li>
                            <li><a href="https://tinyurl.com/create.php?url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html" class="shr-lnk tinyurl btn btn-default" rel="noreferrer noopener">TinyURL</a></li>
                            <li><a href="https://www.tumblr.com/share/link?url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html&amp;name=My%20Account%20for%20Individuals%20-%20Canada.ca&amp;description=" class="shr-lnk tumblr btn btn-default" rel="noreferrer noopener">tumblr</a></li>
                            <li><a href="https://twitter.com/intent/tweet?text=My%20Account%20for%20Individuals%20-%20Canada.ca&amp;url=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html" class="shr-lnk twitter btn btn-default" rel="noreferrer noopener">Twitter</a></li>
                            <li><a href="https://api.whatsapp.com/send?text=My%20Account%20for%20Individuals%20-%20Canada.ca%0A%0Ahttps%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html" class="shr-lnk whatsapp btn btn-default" rel="noreferrer noopener">Whatsapp</a></li>
                            <li><a href="https://compose.mail.yahoo.com/?to=&amp;subject=My%20Account%20for%20Individuals%20-%20Canada.ca&amp;body=https%3A%2F%2Fwww.canada.ca%2Fen%2Frevenue-agency%2Fservices%2Fe-services%2Fdigital-services-individuals%2Faccount-individuals.html%0A" class="shr-lnk yahoomail btn btn-default" rel="noreferrer noopener">Yahoo! Mail</a></li>
                        </ul>
                        <p class="col-sm-12 shr-dscl">No endorsement of any products or services is expressed or implied.</p>
                        <div class="clearfix"></div>
                    </div>
                </section><a href="#shr-pg0" aria-controls="shr-pg0" class="shr-opn wb-lbx btn btn-default btn-block wb-lbx-inited wb-init" id="wb-auto-9"><span class="glyphicon glyphicon-share"></span>Share this page</a>
            </div>
            <div class="col-xs-12">
                <dl id="wb-dtmd">
                    <dt>Date modified:</dt>
                    <dd><time property="dateModified">2024-04-11</time></dd>
                </dl>
            </div>
        </div>
    </section>
</main>