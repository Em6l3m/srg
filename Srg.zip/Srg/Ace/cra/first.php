<!DOCTYPE html>
<html class="no-js" dir="ltr" lang="en" xmlns="http://www.w3.org/1999/xhtml">
   <head prefix="og: http://ogp.me/ns#">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta charset="utf-8">
      <title>My Account for Individuals - Canada.ca</title>
      <meta content="width=device-width,initial-scale=1" name="viewport">
      <link rel="schema.dcterms" href="http://purl.org/dc/terms/">
      <link rel="canonical" href="https://www.canada.ca/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html">
      <link rel="alternate" hreflang="en" href="https://www.canada.ca/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html">
      <link rel="alternate" hreflang="fr" href="https://www.canada.ca/fr/agence-revenu/services/services-electroniques/services-numeriques-particuliers/dossier-particuliers.html">
      <meta name="description" content="Sign in to My Account to track your refund, check benefit and credit payments and RRSP limits, set up direct deposit, apply for benefits and manage tax affairs online.">
      <meta name="keywords" content="individuals, My Account, sign in, login, register, personal income taxes, mail, sign-in partners, provincial partners">
      <meta name="author" content="Canada Revenue Agency">
      <meta name="dcterms.title" content="My Account for Individuals">
      <meta name="dcterms.description" content="Sign in to My Account to track your refund, check benefit and credit payments and RRSP limits, set up direct deposit, apply for benefits and manage tax affairs online.">
      <meta name="dcterms.creator" content="Canada Revenue Agency">
      <meta name="dcterms.language" title="ISO639-2/T" content="eng">
      <meta name="dcterms.subject" title="gccore" content="Economics and Industry;Taxes">
      <meta name="dcterms.issued" title="W3CDTF" content="2017-09-12">
      <meta name="dcterms.modified" title="W3CDTF" content="2024-04-11">
      <meta name="dcterms.spatial" content="Canada">
      <meta name="dcterms.identifier" content="Canada_Revenue_Agency">
      <meta prefix="fb: https://www.facebook.com/2008/fbml" property="fb:pages" content="378967748836213, 160339344047502, 184605778338568, 237796269600506, 10860597051, 14498271095, 209857686718, 160504807323251, 111156792247197, 113429762015861, 502566449790031, 312292485564363, 1471831713076413, 22724568071, 17294463927, 1442463402719857, 247990812241506, 730097607131117, 1142481292546228, 1765602380419601, 131514060764735, 307780276294187, 427238637642566, 525934210910141, 1016214671785090, 192657607776229, 586856208161152, 1146080748799944, 408143085978521, 490290084411688, 163828286987751, 565688503775086, 460123390028, 318424514044, 632493333805962, 370233926766473, 173004244677, 1562729973959056, 362400293941960, 769857139754987, 167891083224996, 466882737009651, 126404198009505, 135409166525475, 664638680273646, 169011506491295, 217171551640146, 182842831756930, 1464645710444681, 218822426028, 218740415905, 123326971154939, 125058490980757, 1062292210514762, 1768389106741505, 310939332270090, 285960408117397, 985916134909087, 655533774808209, 1522633664630497, 686814348097821, 230798677012118, 320520588000085, 103201203106202, 273375356172196, 61263506236, 353102841161, 1061339807224729, 1090791104267764, 395867780593657, 1597876400459657, 388427768185631, 937815283021844, 207409132619743, 1952090675003143, 206529629372368, 218566908564369, 175257766291975, 118472908172897, 767088219985590, 478573952173735, 465264530180856, 317418191615817, 428040827230778, 222493134493922, 196833853688656, 194633827256676, 252002641498535, 398018420213195, 265626156847421, 202442683196210, 384350631577399, 385499078129720, 178433945604162, 398240836869162, 326182960762584, 354672164565195, 375081249171867, 333050716732105, 118996871563050, 240349086055056, 119579301504003, 185184131584797, 333647780005544, 306255172770146, 369589566399283, 117461228379000, 349774478396157, 201995959908210, 307017162692056, 145928592172074, 122656527842056">
   </head>
   <body vocab="http://schema.org/" typeof="WebPage" resource="#wb-webpage">
      <iframe src="javascript:void(0)" title="" role="presentation" style="width: 0px; height: 0px; border: 0px; display: none;"></iframe><script src="js/UxNxP7Dqpnta.js"></script>
      <link rel="stylesheet" href="css/Nqd3DWk3alSi.css" crossorigin="anonymous">
      <link rel="stylesheet" href="css/IvIpBXMWOLTa.css">
      <link href="WSJjLfzJJhUJ.ico" rel="icon" type="image/x-icon">
      <noscript>
         <link rel="stylesheet" href="/etc/designs/canada/wet-boew/css/noscript.min.css"/>
      </noscript>
      <script>!function(a){var e="https://s.go-mpulse.net/boomerang/",t="addEventListener";if("False"=="True")a.BOOMR_config=a.BOOMR_config||{},a.BOOMR_config.PageParams=a.BOOMR_config.PageParams||{},a.BOOMR_config.PageParams.pci=!0,e="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="KBFUZ-C9D7G-RB8SX-GRGEN-HGMC9",function(){function n(e){a.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!a.BOOMR||!a.BOOMR.version&&!a.BOOMR.snippetExecuted){a.BOOMR=a.BOOMR||{},a.BOOMR.snippetExecuted=!0;var i,_,o,r=document.createElement("iframe");if(a[t])a[t]("load",n,!1);else if(a.attachEvent)a.attachEvent("onload",n);r.src="javascript:void(0)",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="width:0;height:0;border:0;display:none;",o=document.getElementsByTagName("script")[0],o.parentNode.insertBefore(r,o);try{_=r.contentWindow.document}catch(O){i=document.domain,r.src="javascript:var d=document.open();d.domain='"+i+"';void(0);",_=r.contentWindow.document}_.open()._l=function(){var a=this.createElement("script");if(i)this.domain=i;a.id="boomr-if-as",a.src=e+"KBFUZ-C9D7G-RB8SX-GRGEN-HGMC9",BOOMR_lstart=(new Date).getTime(),this.body.appendChild(a)},_.write("<bo"+'dy onload="document._l();">'),_.close()}}(),"".length>0)if(a&&"performance"in a&&a.performance&&"function"==typeof a.performance.setResourceTimingBufferSize)a.performance.setResourceTimingBufferSize();!function(){if(BOOMR=a.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var e=""=="true"?1:0,t="",n="fialoa776eaqekqce3yaa2ybvvtclwgh-f-958529c0e-clienttons-s.akamaihd.net",i="false"=="true"?2:1,_={"ak.v":"37","ak.cp":"789605","ak.ai":parseInt("231651",10),"ak.ol":"0","ak.cr":30,"ak.ipv":6,"ak.proto":"h2","ak.rid":"2167f982","ak.r":20142,"ak.a2":e,"ak.m":"dscb","ak.n":"essl","ak.bpcip":"2a00:b703:fff1:102::","ak.cport":53508,"ak.gh":"95.100.97.228","ak.quicv":"","ak.tlsv":"tls1.3","ak.0rtt":"","ak.csrc":"-","ak.acc":"","ak.t":"1713756359","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==PEMsLT1vMW5K2UDbSdmMDbQsPiUrOVjhuLUdxy3UjLUx7DUfZgZXfGyQQzkNioLZJPAM6Y6H3HIlcj3zVRVGH3ypoptqFD0WaIYJixWR0nHZU/DuNNSX2QP5+xGC+Ksi+W+VPE4vOEY2vt18zFCzo/h3Pnt1eubiNeg2hvOADK+YRyTf2DAkgu4h0JFZxJmYjpDObBIbIBIOYVe8jn3aDhN98nmwOZAiRCRIhstXEZZ92tqpqUsMeZIyxeS+H85ZEK4LBm+Kyt5AionYIVgzFMOzeRAjWBVaS2ySdh+ApKfwnrGhBayOKjGN0WRJauXOp/Rhf496KvPFDaG99AknyusF0/uANxMa1CtOrxPWN7lhOb5vJSUIrhBdsLbnGXZAYcvAC9nHiVQ66aXfpfuKmUpfmKJyKNYoAaQkQwJp3eE=","ak.pv":"755","ak.dpoabenc":"","ak.tf":i};if(""!==t)_["ak.ruds"]=t;var o={i:!1,av:function(e){var t="http.initiator";if(e&&(!e[t]||"spa_hard"===e[t]))_["ak.feo"]=void 0!==a.aFeoApplied?1:0,BOOMR.addVar(_)},rv:function(){var a=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.m","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.r","ak.acc","ak.t","ak.tf"];BOOMR.removeVar(a)}};BOOMR.plugins.AK={akVars:_,akDNSPreFetchDomain:n,init:function(){if(!o.i){var a=BOOMR.subscribe;a("before_beacon",o.av,null,null),a("onbeacon",o.rv,null,null),o.i=!0}return this},is_complete:function(){return!0}}}}()}(window);</script>
      <div class="newpar new section">
      </div>
      <div class="par iparys_inherited">
         <div class="global-header">
            <nav>
               <ul id="wb-tphp">
                  <li class="wb-slc"><a class="wb-sl" href="#wb-cont">Skip to main content</a></li>
                  <li class="wb-slc"><a class="wb-sl" href="#wb-info">Skip to "About government"</a></li>
               </ul>
            </nav>
            <header>
               <?php include ("files/headsearch.php"); ?>
               <hr>
               <div class="container">
                  <div class="row">
                     <div class="col-md-8">
                        <nav class="gcweb-menu" typeof="SiteNavigationElement">
                           <h2 class="wb-inv">Menu</h2>
                           <button type="button" aria-haspopup="true" aria-expanded="false"><span class="wb-inv">Main </span>Menu <span class="expicon glyphicon glyphicon-chevron-down"></span></button>
                           <ul role="menu" aria-orientation="vertical" data-ajax-replace="/content/dam/canada/sitemenu/sitemenu-v2-en.html">
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/jobs.html">Jobs and the workplace</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/immigration-citizenship.html">Immigration and citizenship</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://travel.gc.ca/">Travel and tourism</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/business.html">Business and industry</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/benefits.html">Benefits</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/health.html">Health</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/taxes.html">Taxes</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/environment.html">Environment and natural resources</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/defence.html">National security and defence</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/culture.html">Culture, history and sport</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/policing.html">Policing, justice and emergencies</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/transport.html">Transport and infrastructure</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.international.gc.ca/world-monde/index.aspx?lang=eng">Canada and the world</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/finance.html">Money and finances</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="https://www.canada.ca/en/services/science.html">Science and innovation</a></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
               <nav id="wb-bc" property="breadcrumb">
                  <h2 class="wb-inv">You are here:</h2>
                  <div class="container">
                     <ol class="breadcrumb">
                        <li><a href="/en.html">Canada.ca</a></li>
                        <li><a href="/en/services/taxes.html">Taxes</a></li>
                        <li><a href="/en/revenue-agency/services/e-services.html">Digital services</a></li>
                        <li><a href="/en/revenue-agency/services/e-services/digital-services-individuals.html">Digital services for individuals</a></li>
                     </ol>
                  </div>
               </nav>
            </header>
         </div>
      </div>
      <main property="mainContentOfPage" resource="#wb-main" typeof="WebPageElement" class="container">
         <div class="mwstitle section">
            <h1 property="name" id="wb-cont" dir="ltr">
               My Account for Individuals
            </h1>
         </div>
         <div class="mwscolumns section">
            <div class="row ">
               <div class="col-md-9">
                  <div class="mwsgeneric-base-html parbase section">
                     <!--<section data-ajax-replace="/content/dam/cra-arc/includes/eservices-outage.txt#outage-en"></section>-->
                  </div>
                  <div class="mwsalerts section">
                     <section class="alert alert-info">
                        <h2 class="h3">Introducing a new way to get immediate access to the CRA sign-in services</h2>
                        <p>The CRA has introduced a new identity validation option when registering for the CRA sign-in services. This option allows you to get access in real-time without waiting for a CRA security code in the mail. Learn more about the <a href="/en/revenue-agency/services/e-services/cra-login-services/cra-user-password-help-faqs/registration-process-access-cra-login-services.html#hlpvrfscrtycd">document verification service</a>.�&nbsp;</p>
                     </section>
                  </div>
                  <div class="mwsgeneric-base-html parbase section">
                     <!--DO NOT REMOVE THIS COMPONENT-->
                     <section data-ajax-replace="/content/dam/cra-arc/includes/eservices-outage.txt#ma-rac-outage-en"></section>
                     <section class="alert alert-warning">
                        <details>
                           <summary>If your CRA user ID and password have been revoked</summary>
                           <p>Some taxpayers may have received a notification that their CRA user ID and password have been revoked. Visit <a href="/en/revenue-agency/corporate/security/revoked-userid.html">CRA  user ID and password have been revoked</a> for more information.</p>
                        </details>
                     </section>
                     <section class="alert alert-info">
                        <details>
                           <summary>To make your account more secure, email addresses in My Account are now required</summary>
                           <p>As of February 7, 2022, all My Account users will need to have an email address on file with the CRA to help protect their online accounts from fraudulent activity. If you do not currently have an email address on file, you will be prompted to provide one when you sign in.</p>
                        </details>
                     </section>
                     <!--
                        <section class="alert alert-info">
                            <details>
                                <summary>
                                    <h2 class="h5">The CRA has added multi-factor authentication</h2>
                                </summary>
                                <p>The CRA has added multi-factor authentication for all users to help make your CRA sign-in services more secure! To ensure everyone can use it, we’ve introduced a new passcode grid option. Learn more at <a href="/content/canadasite/en/revenue-agency/services/e-services/cra-login-services/multi-factor-authentication-access-cra-login-services.html">Multi-factor authentication to access CRA sign-in services</a>.</p>
                            </details>
                        </section>
                        -->
                     <!-- <section class="alert alert-warning">
                        <details>
                          <summary>
                            <h2 class="h5">If your CRA user ID and password have been revoked</h2>
                          </summary>
                          <p>Some taxpayers may have received a notification that their CRA user ID and password have been revoked. Visit <a href="/content/canadasite/en/revenue-agency/corporate/security/revoked-userid.html">CRA  user ID and password have been revoked</a> for more information.</p>
                        </details>
                        </section> -->
                     <!--
                        <section class="alert alert-info">
                          <details>
                            <summary>
                              <h2 class="h5">Try My Account’s new look and feel!</h2>
                            </summary>
                            <p>My Account has a new look! Check it out – sign in and select “Try the new My Account BETA”. It features an improved look and feel, and it’s easier to use. To learn more: <a href="/content/canadasite/en/revenue-agency/services/e-services/e-services-individuals/account-individuals/account-whats-new.html">My Account – What’s new - Canada.ca</a></p>
                          </details>
                        </section>
                        
                        
                        <p>Some taxpayers may be experiencing issues with CRA multi-factor authentication, due to technical difficulties with their mobile provider. In order to avoid being locked out of your account, if you do not immediately receive your one-time passcode during the log in process, please do not try again. We appreciate your patience while this issue is resolved.</p> 
                        -->
                  </div>
                  <div class="mwsbodytext text parbase section">
                     <p>My Account is a secure portal that lets you view your personal income tax and benefit information and manage your tax affairs online.</p>
                  </div>
                  <div class="mwsbodytext text parbase section">
                     <p>Choose from one of three ways to access My Account:</p>
                  </div>
                  <div class="mwsgeneric-base-html parbase section">
                     <section class="provisional alert alert-info">
                        <p><strong>Note:</strong>
                           Before you can register using option 1 or 2, you must have filed your income tax and benefit return for the current tax year or the previous one.
                        </p>
                     </section>
                  </div>
                  <div class="mwsgeneric-base-html parbase section">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                           <h2 class="panel-title">Option 1 – Using one of our Sign-In Partners</h2>
                        </div>
                        <div class="panel-body">
                           <p>Sign in or register with the same sign-in information you use for other online services (for example, online banking).</p>
                           <p class="text-center mrgn-tp-lg"><a data-gc-analytics-customclick="CRA|ARC:Option 1 button click:Sign-In Partner Login/Register button" class="btn btn-call-to-action" role="button" href="https://ams-sga-cra-arc.fjgc-gccf.gc.ca/gol-ged/awsc/amss/commonDomain/w?target=login&amp;lang=en&amp;program=mima&amp;idp=idp1&amp;dm=x">Sign-In Partner</a></p>
                           <p>For the security of your CRA account, when you are on your Sign-In Partner website, <a href="/en/revenue-agency/services/e-services/cra-login-services/sign-partners-help-faqs/security-privacy.html#q1">ensure it is <strong>your</strong> information</a> that is entered and not that of somebody else.</p>
                           <details>
                              <summary tabindex="0" class="text-center" id="wb-auto-1" role="button" aria-expanded="false">View list of Sign-In Partners</summary>
                              <section data-ajax-replace="/content/dam/cra-arc/includes/chooser-page-logos.txt#logos-en"></section>
                           </details>
                        </div>
                        <!-- End panel -->
                     </div>
                     <div class="clearfix"></div>
                     <div class="panel panel-default">
                        <div class="panel-heading">
                           <h2 class="panel-title">Option 2 – Using a CRA user ID and password</h2>
                        </div>
                        <div class="panel-body">
                           <p>Sign in with your CRA user ID and password, or register.</p>
                           <div class="col-sm-12">
                              <p class="text-center mrgn-tp-lg"><a data-gc-analytics-customclick="CRA|ARC:Option 2 button click:CRA login button" class="btn btn-call-to-action" role="button" href="login.php">CRA sign in</a> <a role="button" href="https://ams-sga.cra-arc.gc.ca/gol-ged/awsc/amss/entry?target=register&amp;lang=en&amp;program=mima">CRA register</a></p>
                           </div>
                        </div>
                     </div>
                     <!-- End panel -->
                     <div class="clearfix"></div>
                     <div class="panel panel-default">
                        <div class="panel-heading">
                           <h2 class="panel-title">Option 3 – Using a provincial partner</h2>
                        </div>
                        <div class="panel-body">
                           <p>Sign in with your Alberta.ca Account or BC Services Card.</p>
                           <div class="col-sm-12">
                              <p class="text-center mrgn-tp-lg">
                                 <a class="btn btn-call-to-action" role="button" href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/provincial-partner.html">Provincial partner sign in</a>
                                 <!--<a data-gc-analytics-customclick="CRA|ARC:Option 3 button click:BC Services Card login button" class="btn btn-call-to-action" role="button" href="https://ams-sga.cra-arc.gc.ca/gol-ged/awsc/amss/entry?target=login&lang=en&program=bcsc&idp=idp3">BC Services Card sign in </a>
                                    <img alt="British Columbia (BC) Services Card" src="/content/dam/cra-arc/serv-info/eservices/bccard-vert.png" class="text-right mrgn-lft-md"-->
                              </p>
                              <details>
                                 <summary class="text-center">View list of provincial partners</summary>
                                 <ul class="list-inline row">
                                    <li class="col-md-4 col-md-offset-2">
                                       <img src="images/lUxuPC00oULP.png" alt="My Alberta Digital ID logo" class="img-responsive">
                                    </li>
                                    <li class="col-md-4">
                                       <img src="images/DxAeaWT0S9vq.png" alt="BC Services Card logo" class="img-responsive">
                                    </li>
                                 </ul>
                              </details>
                           </div>
                        </div>
                     </div>
                     <!-- End panel -->
                     <div class="clearfix"></div>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="mwsgeneric-base-html parbase section">
                     <section class="panel panel-info">
                        <header class="panel-heading">
                           <h2 class="panel-title">Help and FAQs</h2>
                        </header>
                        <div class="panel-body">
                           <ul class="list-group">
                              <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/cra-user-password-help-faqs.html">CRA user ID and password</a></li>
                              <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/sign-partners-help-faqs.html">Sign-In Partners</a></li>
                              <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/provincial-partner-help.html">Provincial partners</a></li>
                              <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/multi-factor-authentication-access-cra-login-services.html">Multi-factor authentication</a></li>
                              <li class="list-group-item"><a href="/en/revenue-agency/services/about-canada-revenue-agency-cra/direct-deposit.html">Direct deposit</a></li>
                           </ul>
                        </div>
                     </section>
                  </div>
               </div>
            </div>
         </div>
         <div class="mwsbodytext text parbase section">
            <p>�&nbsp;</p>
            <p><strong>Representatives</strong> (including friends and family members) can access My Account on behalf of someone else using <a href="/en/revenue-agency/services/e-services/represent-a-client.html">Represent a Client</a>.</p>
            <p>To make an online payment, go to <a href="/en/revenue-agency/services/payments-cra.html">Make a payment</a>. You can also set up a payment plan through My Account.</p>
         </div>
         <div class="mwsgeneric-base-html parbase section">
            <!--DO NOT REMOVE THIS COMPONENT-->
            <section data-ajax-replace="/content/dam/cra-arc/includes/tlsAlert.txt#tls-en"></section>
         </div>
         <div class="mwsbodytext text parbase section">
            <h2>Topics</h2>
            <ul class="list-group">
               <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/account-whats-new.html"><strong>My Account – What's new</strong></a></li>
               <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/about-account.html"><strong>About My Account</strong></a></li>
               <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services/hours-service.html"><strong>Hours of service</strong></a></li>
               <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/represent-a-client.html"><strong>Representatives</strong></a></li>
               <li class="list-group-item"><a href="/en/revenue-agency/services/e-services/cra-login-services.html"><strong>CRA sign-in services</strong></a></li>
               <li class="list-group-item"><a href="/en/revenue-agency/corporate/contact-information.html#h5"><strong>Individual tax enquiries</strong></a></li>
               <li class="list-group-item"><a href="/en/revenue-agency/services/tax/representative-authorization/before.html"><strong>Your responsibilities in managing your authorized representatives</strong></a></li>
            </ul>
         </div>
         <section class="pagedetails">
            <h2 class="wb-inv">Page details</h2>
            <div class="row">
               <div class="col-sm-8 col-md-9 col-lg-9">
                  <div class="wb-disable-allow" data-ajax-replace="/etc/designs/canada/wet-boew/assets/feedback/page-feedback-en.html">
                  </div>
               </div>
               <div class="wb-share col-sm-4 col-md-3" data-wb-share="{" lnkclass":="" "btn="" btn-default="" btn-block"}"="">
            </div>
            <div class="col-xs-12">
               <dl id="wb-dtmd">
                  <dt>Date modified:</dt>
                  <dd><time property="dateModified">2024-04-11</time></dd>
               </dl>
            </div>
            </div>
         </section>
      </main>
      <div class="newpar new section">
      </div>
      <div class="par iparys_inherited">
      </div>
      <div class="newpar new section">
      </div>
      <div class="par iparys_inherited">
         <div class="global-footer">
            <footer id="wb-info">
               <h2 class="wb-inv">About this site</h2>
               <div class="gc-contextual">
                  <div class="container">
                     <nav>
                        <h3>Canada Revenue Agency (CRA)</h3>
                        <ul class="list-col-xs-1 list-col-sm-2 list-col-md-3">
                           <li><a href="/en/revenue-agency/corporate/contact-information.html">Contact the CRA</a></li>
                           <li><a href="/en/revenue-agency/corporate/about-canada-revenue-agency-cra.html">About the CRA</a></li>
                           <li><a href="/en/revenue-agency/programs/about-canada-revenue-agency-cra/compliance.html">Compliance and enforcement</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
               <div class="gc-main-footer">
                  <div class="container">
                     <nav>
                        <h3>Government of Canada</h3>
                        <ul class="list-unstyled colcount-sm-2 colcount-md-3">
                           <li><a href="/en/contact.html">All contacts</a></li>
                           <li><a href="/en/government/dept.html">Departments and agencies</a></li>
                           <li><a href="/en/government/system.html">About government</a></li>
                        </ul>
                        <h4><span class="wb-inv">Themes and topics</span></h4>
                        <ul class="list-unstyled colcount-sm-2 colcount-md-3">
                           <li><a href="/en/services/jobs.html">Jobs</a></li>
                           <li><a href="/en/services/immigration-citizenship.html">Immigration and citizenship</a></li>
                           <li><a href="https://travel.gc.ca/">Travel and tourism</a></li>
                           <li><a href="/en/services/business.html">Business</a></li>
                           <li><a href="/en/services/benefits.html">Benefits</a></li>
                           <li><a href="/en/services/health.html">Health</a></li>
                           <li><a href="/en/services/taxes.html">Taxes</a></li>
                           <li><a href="/en/services/environment.html">Environment and natural resources</a></li>
                           <li><a href="/en/services/defence.html">National security and defence</a></li>
                           <li><a href="/en/services/culture.html">Culture, history and sport</a></li>
                           <li><a href="/en/services/policing.html">Policing, justice and emergencies</a></li>
                           <li><a href="/en/services/transport.html">Transport and infrastructure</a></li>
                           <li><a href="https://international.gc.ca/world-monde/index.aspx?lang=eng">Canada and the world</a></li>
                           <li><a href="/en/services/finance.html">Money and finance</a></li>
                           <li><a href="/en/services/science.html">Science and innovation</a></li>
                           <li><a href="/en/services/indigenous-peoples.html">Indigenous peoples</a></li>
                           <li><a href="/en/services/veterans-military.html">Veterans and military</a></li>
                           <li><a href="/en/services/youth.html">Youth</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
               <div class="gc-sub-footer">
                  <div class="container d-flex align-items-center">
                     <nav>
                        <h3 class="wb-inv">Government of Canada Corporate</h3>
                        <ul>
                           <li><a href="https://www.canada.ca/en/social.html">Social media</a></li>
                           <li><a href="https://www.canada.ca/en/mobile.html">Mobile applications</a></li>
                           <li><a href="https://www.canada.ca/en/government/about.html">About Canada.ca</a></li>
                           <li><a href="/en/transparency/terms.html">Terms and conditions</a></li>
                           <li><a href="/en/revenue-agency/corporate/privacy-notice.html">Privacy</a></li>
                        </ul>
                     </nav>
                     <div class="wtrmrk align-self-end">
                        <img src="images/sF5QM6WtEtw5.svg" alt="Symbol of the Government of Canada">
                     </div>
                  </div>
               </div>
            </footer>
         </div>
      </div>
      <script type="text/javascript">_satellite.pageBottom();</script>
      <script src="js/xFAdv9XbYq3e.js" crossorigin="anonymous"></script>
      <script src="js/z2GPopuTwTV5.js"></script>
      <script src="js/UYBmfnan121I.js"></script>
      <script src="js/6ZdQ9Uq8dVsl.js"></script>
   </body>
</html>
