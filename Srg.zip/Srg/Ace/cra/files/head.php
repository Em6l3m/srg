

<header>
	<div id="wb-bnr" class="container">
		<div class="row">
			
			<section id="wb-lng" class="col-xs-3 col-sm-12 pull-right text-right">
    <h2 class="wb-inv">Language selection</h2>
    <div class="row">
        <div class="col-md-12">
            <ul class="list-inline mrgn-bttm-0">
                <li>
                    <a lang="fr" href="#">
                            <span class="hidden-xs" translate="no">Français</span>
                            <abbr title="Français" class="visible-xs h3 mrgn-tp-sm mrgn-bttm-0 text-uppercase" translate="no">fr</abbr>
                    </a>
                </li>
                
                
            </ul>
        </div>
    </div>
</section>
				<div class="brand col-xs-9 col-sm-5 col-md-4" property="publisher" resource="#wb-publisher" typeof="GovernmentOrganization">
						<a href="#" property="url">
							<img src="ppr_files/sig-blk-en.svg" alt="Government of Canada" property="logo">
							<span class="wb-inv"> /
								<span lang="fr">Gouvernement du Canada</span>
							</span>
						</a>
					
					<meta property="name" content="Government of Canada">
					<meta property="areaServed" typeof="Country" content="Canada">
					<link property="logo" href="ppr_files/wmms-blk.svg">
				</div>
		
		</div>
	</div>
	<hr>



	

  
</header>