<footer id="wb-info" class=" wb-navcurr-inited">
         <div class="brand" style="border-top:4px solid #335175">
            <div class="container">
               <div class="row ">
                  <nav class="col-md-10 ftr-urlt-lnk">
                     <h2 class="wb-inv">About this site</h2>
                     <ul>
                        <li><a href="https://www.canada.ca/en/transparency/terms.html" rel="noopener noreferrer" target="_blank">Terms and conditions</a></li>
                        <li><a href="https://www.canada.ca/en/transparency/privacy.html" rel="noopener noreferrer" target="_blank">Privacy</a></li>
                     </ul>
                  </nav>
                  <div class="col-xs-6 visible-sm visible-xs tofpg">
                     <a href="#web-cont">Top of Page <span class="glyphicon glyphicon-chevron-up"></span></a>
                  </div>
                  <div class="col-xs-6 col-md-3 col-lg-2 text-right">
                     <img src="./images/wmms-blk.svg" alt="Symbol of the Government of Canada">
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!--[if gte IE 9 | !IE ]><!-->
      <!--<![endif]-->
      <!--[if lt IE 9]>
      <script src="/ebci/wet/v5.0.1/wet-boew/js/ie8-wet-boew2.min.js"></script>
      <![endif]-->
      <section id="wb-sessto-modal" style="visibility:hidden" class="mfp-hide modal-dialog modal-content overlay-def">
         <header class="modal-header">
            <h2 class="modal-title">Session timeout warning</h2>
         </header>
         <div class="modal-body" id="modal-body">
            <p>Your session will expire automatically in <span id="timeout-min">3</span> min <span id="timeout-sec">0</span> sec. <br> Select "Continue Session" to extend your session.</p>
         </div>
         <div class="modal-footer" id="modal-footer"><button type="button" class="btn btn-primary popup-modal-dismiss" onclick="awsc.warningTimer.extendSession()">Continue session</button> <button type="button" class="btn btn-default" onclick="awsc.warningTimer.logout()">End session now</button> </div>
      </section>
   </body>
</html>
<!--[if gte IE 9 | !IE ]><!-->
<script src="/ebci/wet/v10.5.4/wet-boew/js/jquery/2.2.4/jquery.min.js"></script>
<script src="/ebci/wet/v10.5.4/wet-boew/js/wet-boew.min.js"></script>
<!--<![endif]-->
<!--[if lt IE 9]>
<script src="/ebci/wet/v5.0.1/wet-boew/js/ie8-wet-boew2.min.js"></script>
<![endif]-->
<script src="/ebci/wet/v10.5.4/GCWeb/js/theme.min.js"></script>
</body>
</html>
