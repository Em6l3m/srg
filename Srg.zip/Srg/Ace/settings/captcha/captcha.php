<?php
session_start();

$code = generateRandomCode(6); // Generate a random code of length 6
$_SESSION['captcha_code'] = $code; // Store the code in session

// Load the background image
$backgroundImage = imagecreatefromjpeg('bg.jpg');

// Get the dimensions of the original background image
$backgroundWidth = imagesx($backgroundImage);
$backgroundHeight = imagesy($backgroundImage);

// Calculate the new dimensions to fit within the CAPTCHA image
$newWidth = 150;
$newHeight = (int) ($backgroundHeight * ($newWidth / $backgroundWidth));

// Create a new image with the new dimensions
$image = imagecreatetruecolor(150, 50);
$background = imagecolorallocatealpha($image, 255, 255, 255, 127); // Add alpha channel for opacity
imagefill($image, 0, 0, $background);

// Resize and copy the background image onto the CAPTCHA image
imagecopyresized($image, $backgroundImage, 0, 0, 0, 0, $newWidth, $newHeight, $backgroundWidth, $backgroundHeight);

$textColor = imagecolorallocate($image, 100, 0, 0);

//dd more random lines for distortion
for ($i = 0; $i < 20; $i++) {
    $lineColor = imagecolorallocate($image, 0, 0, 0);
    imageline($image, rand(0, 150), rand(0, 50), rand(0, 150), rand(0, 50), $lineColor);
}

$fontSize = 18;
$angle = -8;

// Fixed position for the text
$x = 25;
$y = 30;

imagettftext($image, $fontSize, $angle, $x, $y, $textColor, 'fonts/Inter-Bold.ttf', $code);

header("Content-Type: image/png");
imagepng($image);
imagedestroy($image);

function generateRandomCode($length) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $randomCode = '';
    for ($i = 0; $i < $length; $i++) {
        $randomCode .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomCode;
}
?>
