<?php if($html['footer'] == true){ ?>
<footer>
    <div class="legal-footer">
        <div class="application-content">
            <div class="legal-footer-content">
            <div class="inner-row" role="presentation">
                <div class="with-separator">
                    <a class="systemStatus" target="_blank" rel="noreferrer" href="javascript:void(0);" aria-label="System Status (opens in a new tab)">Состояние системы</a>
                    <div aria-hidden="true" class="separator"></div>
                </div>
                <div class="with-separator">
                    <a class="privacy" target="_blank" rel="noreferrer" href="javascript:void(0);" aria-label="Privacy Policy (opens in a new tab)">Политика конфиденциальности</a>
                    <div aria-hidden="true" class="separator"></div>
                </div>
                <a class="terms" target="_blank" rel="noreferrer" href="javascript:void(0);" aria-label="Terms &amp; Conditions (opens in a new tab)">Условия использования</a>
            </div>
            <div class="inner-row" role="presentation"><span class="copyright">Copyright © 2023. All rights reserved.</span></div>
            </div>
        </div>
    </div>
</footer>
<?php } ?>